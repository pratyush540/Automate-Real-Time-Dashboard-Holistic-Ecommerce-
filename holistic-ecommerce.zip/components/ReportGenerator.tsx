
import React, { useState, useEffect, useRef } from 'react';
import { 
  FileText, 
  Download, 
  Lock, 
  Unlock, 
  RefreshCw, 
  Edit3, 
  Save, 
  ShieldAlert, 
  CheckCircle2, 
  FileSearch,
  Printer,
  Share2,
  Maximize2,
  Minimize2,
  Eye,
  AlertTriangle,
  Crown,
  Fingerprint,
  ChevronRight,
  ShieldCheck,
  FileType,
  History,
  RotateCcw,
  Clock,
  ChevronLeft
} from 'lucide-react';
import { MOCK_PRODUCTS, MOCK_CUSTOMERS } from '../constants';

interface ReportVersion {
  id: string;
  content: string;
  timestamp: number;
  label: string;
  author: string;
}

const ReportGenerator: React.FC = () => {
  const [reportContent, setReportContent] = useState<string>('');
  const [isEditing, setIsEditing] = useState(false);
  const [isLocked, setIsLocked] = useState(true);
  const [isGenerating, setIsGenerating] = useState(false);
  const [showAccessDenied, setShowAccessDenied] = useState(false);
  const [password, setPassword] = useState('');
  const [isMaximized, setIsMaximized] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  const [versions, setVersions] = useState<ReportVersion[]>([]);
  
  const reportRef = useRef<HTMLDivElement>(null);

  const saveToHistory = (content: string, label: string) => {
    const newVersion: ReportVersion = {
      id: `REV-${Math.random().toString(36).substr(2, 6).toUpperCase()}`,
      content,
      timestamp: Date.now(),
      label,
      author: 'Global Admin (Node-7)'
    };
    setVersions(prev => [newVersion, ...prev].slice(0, 10));
  };

  const generateReport = () => {
    setIsGenerating(true);
    setTimeout(() => {
      const topProduct = [...MOCK_PRODUCTS].sort((a, b) => b.revenue - a.revenue)[0];
      const totalRevenue = MOCK_PRODUCTS.reduce((acc, p) => acc + p.revenue, 0);
      
      const content = `
# EXECUTIVE STRATEGIC INTELLIGENCE
FISCAL PERIOD: Q4-2024 | LEVEL 5 CLEARANCE | AUTH: ALPHA-OMEGA-9

## EXECUTIVE SUMMARY
The enterprise has demonstrated exceptional resilience, yielding a consolidated revenue profile of $${totalRevenue.toLocaleString()}. Strategic market positioning remains dominant in core categories, specifically within the electronics sector, where growth has outpaced industry benchmarks by 4.2%.

## CORE PERFORMANCE INDICATORS
- **Gross Consolidated Revenue:** $${totalRevenue.toLocaleString()}
- **Market Share Growth:** +2.8% WoW
- **Operational Efficiency:** 94.2%
- **Primary Revenue Driver:** ${topProduct.name}

## STRATEGIC REVENUE NODES
The performance of **${topProduct.name}** continues to anchor our fiscal stability. With a conversion rate of ${(topProduct.conversionRate * 100).toFixed(1)}%, this asset represents our most efficient capital-to-revenue bridge. 

## FORWARD-LOOKING GUIDANCE
- **Asset Allocation:** Diversify inventory into high-velocity "Regular" customer segments to mitigate "VIP" dependency.
- **Logistics Optimization:** Implement predictive route modeling to eliminate West Coast latency issues.
- **Acquisition Strategy:** Leverage behavioral lookalikes based on the current VIP profile database.

---
CONFIDENTIAL | FOR BOARD REVIEW ONLY | ENCRYPTED AT SOURCE
      `;
      setReportContent(content.trim());
      saveToHistory(content.trim(), 'Automated System Generation');
      setIsGenerating(false);
    }, 1500);
  };

  useEffect(() => {
    generateReport();
  }, []);

  const handleDownload = () => {
    if (isLocked) {
      setShowAccessDenied(true);
      setTimeout(() => setShowAccessDenied(false), 3000);
      return;
    }
    
    const htmlContent = `
      <!DOCTYPE html>
      <html lang="en">
      <head>
        <meta charset="UTF-8">
        <title>Executive Brief - ${new Date().toLocaleDateString()}</title>
        <style>
          @import url('https://fonts.googleapis.com/css2?family=Crimson+Pro:wght@400;700&family=Inter:wght@400;600;900&display=swap');
          body { font-family: 'Inter', sans-serif; line-height: 1.8; color: #1e293b; padding: 80px; max-width: 900px; margin: auto; background: #fff; }
          h1 { font-family: 'Crimson Pro', serif; font-size: 3.5rem; color: #0f172a; border-bottom: 2px solid #0f172a; padding-bottom: 20px; margin-bottom: 50px; text-transform: uppercase; letter-spacing: -0.02em; text-align: center; }
          h2 { font-family: 'Inter', sans-serif; font-size: 1.2rem; font-weight: 900; color: #334155; margin-top: 60px; border-bottom: 1px solid #e2e8f0; padding-bottom: 10px; text-transform: uppercase; letter-spacing: 0.2em; color: #2563eb; }
          p { margin-bottom: 25px; font-size: 1.15rem; color: #334155; }
          ul { list-style-type: none; padding: 0; }
          li { margin-bottom: 15px; padding: 20px; background: #f8fafc; border-left: 4px solid #2563eb; border-radius: 4px; font-weight: 500; }
          hr { margin: 80px 0; border: 0; border-top: 2px solid #0f172a; }
          .footer { font-size: 0.9rem; color: #94a3b8; text-align: center; margin-top: 60px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.1em; }
          .watermark { position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%) rotate(-45deg); font-size: 8rem; color: rgba(0,0,0,0.03); font-weight: 900; z-index: -1; pointer-events: none; }
          @media print {
            body { padding: 40px; }
            .no-print { display: none; }
          }
        </style>
      </head>
      <body>
        <div class="watermark">CONFIDENTIAL</div>
        ${reportContent.split('\n').map(line => {
          if (line.startsWith('# ')) return `<h1>${line.replace('# ', '')}</h1>`;
          if (line.startsWith('## ')) return `<h2>${line.replace('## ', '')}</h2>`;
          if (line.startsWith('- ')) return `<li>${line.replace('- ', '')}</li>`;
          if (line.startsWith('---')) return `<hr>`;
          return `<p>${line}</p>`;
        }).join('')}
        <div class="footer">Holistic Enterprise Intelligence Protocol System-V4</div>
      </body>
      </html>
    `;

    const blob = new Blob([htmlContent], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Executive_Strategic_Report_${new Date().toISOString().split('T')[0]}.html`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handlePdfExport = () => {
    if (isLocked) {
      setShowAccessDenied(true);
      setTimeout(() => setShowAccessDenied(false), 3000);
      return;
    }
    window.print();
  };

  const handleEditToggle = () => {
    if (isLocked) {
      setShowAccessDenied(true);
      setTimeout(() => setShowAccessDenied(false), 3000);
      return;
    }
    
    if (isEditing) {
      saveToHistory(reportContent, 'Manual Executive Override');
    }
    
    setIsEditing(!isEditing);
  };

  const revertToVersion = (version: ReportVersion) => {
    if (confirm(`Revert to Audit Signature ${version.id}? Unsaved current drafts will be archived.`)) {
      setReportContent(version.content);
      setShowHistory(false);
      saveToHistory(version.content, `Reverted to ${version.id}`);
    }
  };

  const verifyAccess = () => {
    if (password === 'admin123') {
      setIsLocked(false);
      setPassword('');
    } else {
      alert('Security Breach Notification Sent to Compliance');
    }
  };

  const getTimeAgo = (ts: number) => {
    const diff = Math.floor((Date.now() - ts) / 1000);
    if (diff < 60) return 'seconds ago';
    if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
    return `${Math.floor(diff / 3600)}h ago`;
  };

  return (
    <div className={`space-y-12 animate-in fade-in duration-1000 ${isMaximized ? 'fixed inset-0 z-[100] bg-slate-50 overflow-y-auto p-12' : ''}`}>
      {!isMaximized && (
        <div className="bg-slate-950 p-16 rounded-[4rem] text-white relative overflow-hidden shadow-[0_50px_100px_-20px_rgba(0,0,0,0.5)] border border-slate-800">
          <div className="absolute top-0 right-0 w-[800px] h-[800px] bg-blue-600/5 rounded-full blur-[150px] -translate-y-1/2 translate-x-1/2"></div>
          <div className="absolute bottom-0 left-0 w-[600px] h-[600px] bg-indigo-600/5 rounded-full blur-[120px] translate-y-1/2 -translate-x-1/2"></div>
          
          <div className="relative z-10 flex flex-col xl:flex-row justify-between items-start xl:items-center gap-12">
            <div className="max-w-3xl">
              <div className="inline-flex items-center gap-3 px-5 py-2.5 bg-gradient-to-r from-blue-500/10 to-indigo-500/10 rounded-full border border-blue-400/20 text-blue-300 text-xs font-black uppercase tracking-[0.25em] mb-8">
                <Crown size={16} className="text-amber-400" /> Executive Board Portal
              </div>
              <h2 className="text-6xl font-black mb-6 tracking-tighter leading-[0.9] bg-gradient-to-b from-white to-slate-400 bg-clip-text text-transparent">
                Strategic Intelligence <br/>Compilation Engine
              </h2>
              <p className="text-slate-400 text-xl leading-relaxed font-medium">
                Synthesize real-time operational data into high-fidelity board-ready documents. 
                Authenticated by Holistic Governance Protocols.
              </p>
            </div>
            
            <div className="flex flex-col gap-5 w-full xl:w-80">
              <button 
                onClick={generateReport}
                disabled={isGenerating}
                className="group relative w-full overflow-hidden flex items-center justify-center gap-4 bg-white text-slate-950 px-10 py-6 rounded-[2rem] font-black text-sm transition-all hover:scale-[1.02] active:scale-95 disabled:opacity-50"
              >
                <div className="absolute inset-0 bg-gradient-to-r from-blue-400 to-indigo-400 translate-y-full group-hover:translate-y-0 transition-transform duration-500"></div>
                <RefreshCw size={22} className={`relative z-10 ${isGenerating ? 'animate-spin' : ''}`} />
                <span className="relative z-10 group-hover:text-white transition-colors">Compile Board Briefing</span>
              </button>
              
              <div className="grid grid-cols-2 gap-4">
                <button onClick={() => { if(!isLocked) window.print() }} className={`flex items-center justify-center gap-2 py-5 rounded-[1.5rem] font-bold text-xs uppercase tracking-widest transition-all ${isLocked ? 'bg-slate-900 text-slate-600 cursor-not-allowed' : 'bg-slate-900 text-slate-200 hover:bg-slate-800 border border-slate-700'}`}>
                  <Printer size={18} /> Print
                </button>
                <button className="flex items-center justify-center gap-2 py-5 bg-slate-900 text-slate-200 rounded-[1.5rem] font-bold text-xs uppercase tracking-widest border border-slate-700 hover:bg-slate-800 transition-all">
                  <Share2 size={18} /> Vault
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      <div className={`grid grid-cols-1 ${isMaximized ? '' : 'lg:grid-cols-4'} gap-12`}>
        <div className={`${isMaximized ? 'w-full' : 'lg:col-span-3'} space-y-8 relative`}>
          <div className={`bg-white rounded-[3.5rem] border border-slate-200 shadow-[0_40px_80px_-30px_rgba(0,0,0,0.1)] overflow-hidden flex flex-col ${isMaximized ? 'min-h-screen' : 'h-[900px]'} transition-all duration-700`}>
            
            <div className="p-10 bg-slate-50/50 border-b border-slate-100 flex items-center justify-between no-print">
              <div className="flex items-center gap-6">
                <div className={`w-14 h-14 rounded-2xl flex items-center justify-center shadow-lg transition-all duration-500 ${isEditing ? 'bg-amber-100 text-amber-600' : 'bg-slate-900 text-white'}`}>
                  {isEditing ? <Edit3 size={28} /> : <FileText size={28} />}
                </div>
                <div>
                  <h3 className="text-2xl font-black text-slate-900 tracking-tight">{isEditing ? 'Drafting Terminal' : 'Intelligence Preview'}</h3>
                  <div className="flex items-center gap-3 mt-1">
                    <div className="flex items-center gap-1.5 px-2.5 py-1 bg-emerald-50 rounded-full border border-emerald-100">
                      <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse"></span>
                      <span className="text-[9px] text-emerald-600 font-black uppercase tracking-tighter">Live Sync</span>
                    </div>
                    <span className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Global Encrypted Node-7</span>
                  </div>
                </div>
              </div>
              
              <div className="flex items-center gap-4">
                <button 
                  onClick={() => setShowHistory(!showHistory)}
                  className={`p-4 rounded-2xl border transition-all flex items-center gap-3 shadow-sm ${showHistory ? 'bg-blue-600 text-white border-blue-700' : 'bg-white text-slate-400 border-slate-200 hover:bg-slate-50'}`}
                  title="Version History"
                >
                  <History size={22} />
                </button>
                <button 
                  onClick={handleEditToggle}
                  className={`px-8 py-4 rounded-2xl border transition-all flex items-center gap-3 text-sm font-black tracking-tight
                    ${isEditing ? 'bg-slate-900 text-white border-slate-950 shadow-xl' : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50 shadow-sm'}`}
                >
                  {isEditing ? <><Save size={20} /> Commit Changes</> : <><Edit3 size={20} /> Authorize Modification</>}
                </button>
                <button 
                  onClick={() => setIsMaximized(!isMaximized)}
                  className="p-4 bg-white text-slate-400 border border-slate-200 rounded-2xl hover:text-slate-950 transition-all shadow-sm active:scale-90"
                >
                  {isMaximized ? <Minimize2 size={22} /> : <Maximize2 size={22} />}
                </button>
              </div>
            </div>
            
            <div className={`flex-1 p-12 md:p-24 overflow-y-auto custom-scrollbar bg-slate-50 transition-colors duration-500 ${isEditing ? 'bg-white' : ''} print:bg-white print:p-0 relative`}>
              
              {showHistory && (
                <div className="absolute inset-y-0 right-0 w-80 bg-white border-l border-slate-100 shadow-2xl z-20 animate-in slide-in-from-right-4 duration-300 no-print">
                  <div className="p-8 bg-slate-50 border-b border-slate-100 flex items-center justify-between">
                    <h4 className="text-sm font-black text-slate-900 uppercase tracking-widest">Audit History</h4>
                    <button onClick={() => setShowHistory(false)} className="text-slate-400 hover:text-slate-900"><ChevronLeft size={20} /></button>
                  </div>
                  <div className="p-4 space-y-4 h-[calc(100%-80px)] overflow-y-auto custom-scrollbar">
                    {versions.map((v, i) => (
                      <div 
                        key={v.id} 
                        className="p-5 rounded-2xl bg-white border border-slate-100 hover:border-blue-400 hover:shadow-xl transition-all group cursor-pointer"
                        onClick={() => revertToVersion(v)}
                      >
                        <div className="flex items-center justify-between mb-3">
                          <span className="text-[10px] font-black text-blue-600 bg-blue-50 px-2 py-1 rounded-md">{v.id}</span>
                          <span className="text-[9px] text-slate-400 font-bold">{getTimeAgo(v.timestamp)}</span>
                        </div>
                        <h5 className="text-sm font-black text-slate-800 leading-tight mb-2">{v.label}</h5>
                        <p className="text-[10px] text-slate-400 font-bold mb-4 italic truncate">{v.content.substring(0, 100)}...</p>
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-1.5">
                            <Clock size={12} className="text-slate-300" />
                            <span className="text-[9px] text-slate-500 font-black">{new Date(v.timestamp).toLocaleTimeString()}</span>
                          </div>
                          <button className="flex items-center gap-1.5 text-[10px] font-black text-blue-600 opacity-0 group-hover:opacity-100 transition-opacity">
                            <RotateCcw size={12} /> Revert
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {isGenerating ? (
                <div className="h-full flex flex-col items-center justify-center space-y-8 no-print">
                  <div className="relative">
                    <div className="w-32 h-32 border-4 border-slate-200 border-t-slate-900 rounded-full animate-spin"></div>
                    <ShieldCheck className="absolute inset-0 m-auto text-slate-900" size={48} />
                  </div>
                  <div className="text-center">
                    <p className="font-black text-slate-900 uppercase tracking-[0.4em] text-sm">Aggregating Global Silos</p>
                    <p className="text-slate-400 text-xs font-bold mt-2">Verified Security Token: X-992-ALPHA</p>
                  </div>
                </div>
              ) : (
                <div id="report-document" ref={reportRef} className="max-w-4xl mx-auto bg-white p-20 shadow-[0_60px_100px_-40px_rgba(0,0,0,0.15)] rounded-lg min-h-full border-t-[20px] border-slate-950 print:shadow-none print:border-none print:p-10 animate-in slide-in-from-bottom-12 duration-1000">
                  {isEditing ? (
                    <textarea 
                      value={reportContent}
                      onChange={(e) => setReportContent(e.target.value)}
                      className="w-full h-full min-h-[700px] border-none focus:ring-0 p-0 text-slate-800 leading-loose resize-none font-serif text-2xl bg-transparent selection:bg-blue-100"
                      spellCheck={false}
                      autoFocus
                    />
                  ) : (
                    <div className="prose prose-slate max-w-none text-slate-900 leading-relaxed font-serif">
                      <div className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 -rotate-45 text-[8rem] font-black text-slate-950/5 pointer-events-none select-none uppercase hidden print:block">
                        Confidential
                      </div>
                      {reportContent.split('\n').map((line, idx) => {
                        if (line.startsWith('# ')) return (
                          <div key={idx} className="mb-20 text-center relative">
                            <h1 className="text-6xl font-black text-slate-950 mb-4 tracking-tighter uppercase">{line.replace('# ', '')}</h1>
                            <div className="w-24 h-1 bg-slate-900 mx-auto rounded-full"></div>
                          </div>
                        );
                        if (line.startsWith('## ')) return <h2 key={idx} className="text-2xl font-black text-blue-600 mt-20 mb-8 pb-3 border-b-2 border-slate-100 uppercase tracking-widest">{line.replace('## ', '')}</h2>;
                        if (line.startsWith('- ')) return (
                          <div key={idx} className="flex gap-6 mb-6 group">
                            <div className="w-1.5 h-1.5 bg-slate-950 rounded-full mt-3.5 shrink-0 group-hover:scale-[3] transition-transform"></div>
                            <p className="text-slate-800 text-xl font-medium leading-relaxed italic">{line.replace('- ', '')}</p>
                          </div>
                        );
                        if (line.startsWith('---')) return <hr key={idx} className="my-20 border-slate-950 border-t-2" />;
                        return <p key={idx} className="mb-8 text-2xl text-slate-700 leading-[1.8] font-light">{line}</p>;
                      })}
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>

        {!isMaximized && (
          <div className="space-y-12 no-print">
            <div className={`bg-white p-10 rounded-[3.5rem] border shadow-2xl relative overflow-hidden transition-all duration-700 ${isLocked ? 'border-slate-200' : 'border-blue-200 shadow-blue-500/10'}`}>
              <div className="flex items-center gap-5 mb-10">
                <div className={`w-16 h-16 rounded-[1.5rem] flex items-center justify-center transition-all duration-700 ${isLocked ? 'bg-slate-950 text-white shadow-2xl' : 'bg-blue-600 text-white shadow-2xl shadow-blue-600/30'}`}>
                  {isLocked ? <Fingerprint size={32} /> : <Unlock size={32} />}
                </div>
                <div>
                  <h4 className="font-black text-slate-950 tracking-tight text-xl uppercase">Vault Access</h4>
                  <p className="text-[10px] text-slate-400 font-black uppercase tracking-[0.2em]">{isLocked ? 'Encryption Locked' : 'Verified Identity'}</p>
                </div>
              </div>

              {isLocked ? (
                <div className="space-y-8">
                  <div className="p-6 bg-slate-50 rounded-2xl border border-slate-100 flex items-start gap-4">
                    <AlertTriangle size={24} className="text-amber-500 shrink-0 mt-0.5" />
                    <p className="text-sm text-slate-600 font-bold leading-relaxed italic">
                      High-level strategic assets are restricted to Board Members.
                    </p>
                  </div>
                  <div className="space-y-3">
                    <label className="text-[11px] font-black text-slate-400 uppercase tracking-[0.3em] ml-2">Verification Key</label>
                    <input 
                      type="password" 
                      placeholder="ENTER PIN..." 
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="w-full p-6 bg-slate-50 border border-slate-200 rounded-[2rem] text-sm focus:ring-0 focus:outline-none focus:border-slate-950 transition-all font-mono text-center tracking-[0.5em] text-xl"
                    />
                    <p className="text-[9px] text-slate-300 font-bold text-center">Bypass Hint: <span className="text-slate-400">admin123</span></p>
                  </div>
                  <button 
                    onClick={verifyAccess}
                    className="group w-full py-6 bg-slate-950 text-white rounded-[2rem] font-black text-sm hover:bg-slate-900 transition-all shadow-2xl shadow-slate-900/40 active:scale-95 flex items-center justify-center gap-3"
                  >
                    Authorize Session <ChevronRight size={18} className="group-hover:translate-x-1 transition-transform" />
                  </button>
                </div>
              ) : (
                <div className="space-y-8 animate-in zoom-in-95 duration-500">
                  <div className="p-8 bg-blue-50 rounded-[2.5rem] border border-blue-100 flex flex-col items-center text-center gap-4">
                    <div className="bg-blue-600 p-4 rounded-full text-white shadow-xl shadow-blue-600/30 animate-bounce"><ShieldCheck size={40} /></div>
                    <div>
                      <h5 className="font-black text-blue-900 text-xl">Identity Verified</h5>
                      <p className="text-xs text-blue-600 font-bold mt-1 uppercase tracking-widest">Global Admin Access</p>
                    </div>
                  </div>
                  <div className="grid grid-cols-1 gap-4">
                    <div className="p-5 bg-slate-50 rounded-2xl border border-slate-100 flex justify-between items-center group cursor-default">
                      <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest group-hover:text-blue-600 transition-colors">Audit Status</span>
                      <span className="text-xs font-black text-slate-900">ACTIVE-REC</span>
                    </div>
                    <div className="p-5 bg-slate-50 rounded-2xl border border-slate-100 flex justify-between items-center">
                      <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Enc Type</span>
                      <span className="text-xs font-black text-blue-600">QUANTUM-RES</span>
                    </div>
                  </div>
                  <button 
                    onClick={() => { setIsLocked(true); setIsEditing(false); }}
                    className="w-full py-6 bg-white text-rose-600 border border-rose-200 rounded-[2rem] font-black text-xs uppercase tracking-widest hover:bg-rose-50 transition-all active:scale-95"
                  >
                    Revoke Authentication
                  </button>
                </div>
              )}
            </div>

            <div className={`p-12 rounded-[4rem] border transition-all duration-700 flex flex-col items-center text-center space-y-6 shadow-2xl relative group
              ${isLocked ? 'bg-slate-100 border-slate-200 grayscale opacity-60 cursor-not-allowed' : 'bg-slate-950 border-slate-800 text-white shadow-slate-950/40'}`}>
              
              <div className={`w-24 h-24 rounded-[2rem] flex items-center justify-center transition-all duration-1000 relative
                ${isLocked ? 'bg-slate-200 text-slate-400' : 'bg-white text-slate-950 rotate-12 scale-110 shadow-[0_30px_60px_-12px_rgba(255,255,255,0.3)] group-hover:rotate-0'}`}>
                <Download size={48} />
                {isLocked && <Lock size={20} className="absolute top-4 right-4 text-rose-500" />}
              </div>
              
              <div>
                <h4 className={`text-2xl font-black mb-2 tracking-tighter uppercase ${isLocked ? 'text-slate-500' : 'text-white'}`}>Intelligence Export</h4>
                <p className={`text-xs ${isLocked ? 'text-slate-400' : 'text-slate-400'} leading-relaxed font-bold px-2`}>
                  Generate high-fidelity strategic blueprints for high-level board discussions.
                </p>
              </div>
              
              {showAccessDenied && (
                <div className="absolute inset-0 bg-rose-600/95 flex flex-col items-center justify-center p-12 rounded-[4rem] text-white animate-in slide-in-from-top-4 duration-300 z-20">
                  <Fingerprint size={64} className="mb-6 animate-pulse" />
                  <h5 className="text-2xl font-black uppercase tracking-widest">Unauthorized Access</h5>
                  <p className="text-sm font-bold opacity-80 mt-2 text-center">Identity confirmation required to lift security locks.</p>
                </div>
              )}

              <div className="w-full space-y-4">
                <button 
                  onClick={handlePdfExport}
                  className={`w-full py-6 rounded-[2rem] font-black text-xs uppercase tracking-widest transition-all active:scale-95 flex items-center justify-center gap-4 shadow-xl
                    ${isLocked ? 'bg-slate-200 text-slate-400 cursor-not-allowed' : 'bg-indigo-600 text-white hover:bg-indigo-500 shadow-indigo-600/30'}`}
                >
                  {!isLocked ? <FileType size={20} /> : <Lock size={20} />}
                  Export PDF Document
                </button>
                <button 
                  onClick={handleDownload}
                  className={`w-full py-6 rounded-[2rem] font-black text-xs uppercase tracking-widest transition-all active:scale-95 flex items-center justify-center gap-4 shadow-xl
                    ${isLocked ? 'bg-slate-200 text-slate-400 cursor-not-allowed' : 'bg-blue-600 text-white hover:bg-blue-500 shadow-blue-600/30'}`}
                >
                  {!isLocked ? <Download size={20} /> : <Lock size={20} />}
                  Download Source HTML
                </button>
              </div>
            </div>

            <div className="bg-slate-50 p-8 rounded-[3rem] border border-slate-200 flex items-start gap-6 shadow-sm group">
              <div className="p-4 bg-white text-slate-950 rounded-2xl shadow-lg shrink-0 group-hover:rotate-180 transition-transform duration-1000">
                <RefreshCw size={28} />
              </div>
              <div>
                <h5 className="text-lg font-black text-slate-900 tracking-tight">Quantum Persistence</h5>
                <p className="text-xs text-slate-500 mt-2 leading-relaxed font-bold uppercase tracking-tighter">Your edits are cryptographically signed and synced to the core ledger every 120s.</p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ReportGenerator;

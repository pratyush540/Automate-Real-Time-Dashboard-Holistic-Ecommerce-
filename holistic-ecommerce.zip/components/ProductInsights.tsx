
import React from 'react';
import { 
  ScatterChart, 
  Scatter, 
  XAxis, 
  YAxis, 
  ZAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer 
} from 'recharts';
import { MOCK_PRODUCTS } from '../constants';

const ProductInsights: React.FC = () => {
  const sortedByRevenue = [...MOCK_PRODUCTS].sort((a, b) => b.revenue - a.revenue).slice(0, 10);
  
  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-white p-8 rounded-2xl border border-slate-200 shadow-sm">
          <div className="mb-6">
            <h3 className="text-lg font-bold text-slate-800">Product Velocity vs Conversion</h3>
            <p className="text-sm text-slate-500">Bubble size represents total revenue</p>
          </div>
          <div className="h-[400px]">
            <ResponsiveContainer width="100%" height="100%">
              <ScatterChart margin={{ top: 20, right: 20, bottom: 20, left: 20 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis 
                  type="number" 
                  dataKey="velocity" 
                  name="Velocity" 
                  unit=" units/day" 
                  axisLine={false} 
                  tickLine={false} 
                />
                <YAxis 
                  type="number" 
                  dataKey="conversionRate" 
                  name="Conv. Rate" 
                  unit="%" 
                  axisLine={false} 
                  tickLine={false} 
                  tickFormatter={(val) => `${(val * 100).toFixed(0)}%`}
                />
                <ZAxis type="number" dataKey="revenue" range={[100, 1000]} name="Revenue" unit="$" />
                <Tooltip cursor={{ strokeDasharray: '3 3' }} />
                <Scatter name="Products" data={MOCK_PRODUCTS} fill="#3b82f6" fillOpacity={0.6} />
              </ScatterChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white p-8 rounded-2xl border border-slate-200 shadow-sm">
          <h3 className="text-lg font-bold text-slate-800 mb-6">Top 10 Selling Products</h3>
          <div className="overflow-x-auto custom-scrollbar">
            <table className="w-full text-left">
              <thead>
                <tr className="text-slate-400 text-xs font-bold uppercase tracking-wider border-b border-slate-100">
                  <th className="pb-3">Product Name</th>
                  <th className="pb-3 text-right">Revenue</th>
                  <th className="pb-3 text-right">Sold</th>
                  <th className="pb-3 text-right">Velocity</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {sortedByRevenue.map((p) => (
                  <tr key={p.id} className="group hover:bg-slate-50 transition-colors">
                    <td className="py-4 text-sm font-semibold text-slate-700">{p.name}</td>
                    <td className="py-4 text-sm text-right font-mono text-slate-600">${p.revenue.toLocaleString()}</td>
                    <td className="py-4 text-sm text-right text-slate-500 font-medium">{p.quantitySold}</td>
                    <td className="py-4 text-sm text-right">
                      <span className="text-blue-600 font-bold">{p.velocity}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-8 border-b border-slate-100">
          <h3 className="text-lg font-bold text-slate-800">Complete Product Inventory Matrix</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-slate-50 text-slate-500 text-xs font-bold uppercase">
              <tr>
                <th className="px-8 py-4">Product</th>
                <th className="px-4 py-4">Category</th>
                <th className="px-4 py-4 text-right">Clicks</th>
                <th className="px-4 py-4 text-right">Conv. Rate</th>
                <th className="px-4 py-4 text-right">Revenue</th>
                <th className="px-4 py-4 text-right">Stock</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {MOCK_PRODUCTS.map((p) => (
                <tr key={p.id} className="hover:bg-slate-50/50 transition-colors">
                  <td className="px-8 py-4 font-semibold text-slate-800">{p.name}</td>
                  <td className="px-4 py-4">
                    <span className="text-xs font-bold bg-slate-100 text-slate-600 px-2.5 py-1 rounded-full">{p.category}</span>
                  </td>
                  <td className="px-4 py-4 text-right font-mono text-slate-500">{p.clicks.toLocaleString()}</td>
                  <td className="px-4 py-4 text-right font-semibold text-emerald-600">{(p.conversionRate * 100).toFixed(1)}%</td>
                  <td className="px-4 py-4 text-right font-bold text-slate-700">${p.revenue.toLocaleString()}</td>
                  <td className="px-4 py-4 text-right">
                    <span className={`font-bold ${p.stock <= p.reorderPoint ? 'text-red-500' : 'text-slate-500'}`}>{p.stock}</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default ProductInsights;

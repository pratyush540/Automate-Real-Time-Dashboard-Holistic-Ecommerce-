
import React, { useState, useEffect } from 'react';
import { 
  Package, 
  Truck, 
  CheckCircle, 
  MapPin, 
  AlertCircle, 
  RefreshCcw, 
  Search, 
  Clock, 
  Activity, 
  Globe, 
  Navigation, 
  ShieldCheck,
  Zap,
  ArrowUpRight
} from 'lucide-react';
import { MOCK_ORDERS } from '../constants';
import { Order } from '../types';

const OrderTracking: React.FC = () => {
  const [orders, setOrders] = useState<Order[]>(MOCK_ORDERS);
  const [lastUpdate, setLastUpdate] = useState<string>('Just now');
  const [activeTelemetry, setActiveTelemetry] = useState<string>("Scanning global fleet...");

  useEffect(() => {
    const telemetryLines = [
      "Optimizing West Coast routes...",
      "Syncing GPS coordinates for ORD-772...",
      "Weather patterns analyzed for East Sector.",
      "Fuel efficiency protocol: Active.",
      "Last-mile delivery estimated: 98.4% success.",
      "Warehouse node 4 synchronized.",
    ];

    const interval = setInterval(() => {
      setOrders(prev => {
        return prev.map(order => {
          if (order.status === 'Placed' && Math.random() > 0.85) {
            return { ...order, status: 'Shipped', time: 'Just now' };
          }
          if (order.status === 'Shipped' && Math.random() > 0.9) {
            return { ...order, status: 'Delivered', time: 'Just now' };
          }
          return order;
        });
      });
      setLastUpdate(new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
      setActiveTelemetry(telemetryLines[Math.floor(Math.random() * telemetryLines.length)]);
    }, 4000);

    return () => clearInterval(interval);
  }, []);

  const getStatusStyle = (status: string) => {
    switch (status) {
      case 'Delivered': return { color: 'text-emerald-400', bg: 'bg-emerald-500/10', border: 'border-emerald-500/20', icon: <CheckCircle size={20} /> };
      case 'Shipped': return { color: 'text-blue-400', bg: 'bg-blue-500/10', border: 'border-blue-500/20', icon: <Truck size={20} /> };
      case 'Placed': return { color: 'text-amber-400', bg: 'bg-amber-500/10', border: 'border-amber-500/20', icon: <Package size={20} /> };
      case 'Issue': return { color: 'text-rose-400', bg: 'bg-rose-500/10', border: 'border-rose-500/20', icon: <AlertCircle size={20} /> };
      default: return { color: 'text-slate-400', bg: 'bg-slate-500/10', border: 'border-slate-500/20', icon: <Navigation size={20} /> };
    }
  };

  return (
    <div className="space-y-10 animate-in fade-in duration-1000">
      {/* Executive Logistics Command Header */}
      <div className="bg-slate-950 rounded-[4rem] p-12 relative overflow-hidden shadow-[0_50px_100px_-20px_rgba(0,0,0,0.4)] border border-slate-800">
        <div className="absolute inset-0 opacity-20 pointer-events-none">
          <div className="grid grid-cols-24 grid-rows-24 h-full w-full">
            {Array.from({ length: 576 }).map((_, i) => (
              <div key={i} className="border-[0.5px] border-slate-700"></div>
            ))}
          </div>
        </div>
        
        <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-blue-600/10 rounded-full blur-[120px] -translate-y-1/2 translate-x-1/2"></div>
        
        <div className="relative z-10 flex flex-col xl:flex-row justify-between items-start xl:items-center gap-12">
          <div className="max-w-2xl">
            <div className="flex items-center gap-4 mb-6">
              <div className="flex h-4 w-4 rounded-full bg-emerald-500 animate-ping"></div>
              <span className="text-xs font-black text-emerald-400 uppercase tracking-[0.3em]">Neural Fleet Telemetry: Online</span>
            </div>
            <h2 className="text-6xl font-black text-white tracking-tighter leading-[0.9] mb-6">
              Global Logistics <br/>Command Center
            </h2>
            <p className="text-slate-400 text-xl leading-relaxed font-medium">
              Overseeing end-to-end fulfillment cycles with sub-second GPS resolution. Real-time auditing of delivery nodes and carrier performance.
            </p>
          </div>
          
          <div className="flex flex-col gap-6 w-full xl:w-96">
            <div className="bg-white/5 backdrop-blur-2xl p-8 rounded-[2.5rem] border border-white/10 flex items-center justify-between gap-8 shadow-2xl">
              <div className="space-y-1">
                <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Global Clock</p>
                <p className="text-3xl font-black text-white font-mono">{lastUpdate}</p>
              </div>
              <div className="bg-blue-600 p-4 rounded-2xl shadow-xl shadow-blue-600/30">
                <Globe size={32} className="text-white animate-spin-slow" />
              </div>
            </div>
            
            <div className="bg-slate-900/50 p-6 rounded-[2rem] border border-slate-800 flex items-center gap-4">
              <Activity size={20} className="text-blue-500 animate-pulse" />
              <p className="text-xs font-mono text-blue-300 uppercase tracking-tighter truncate">
                {activeTelemetry}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Dynamic Key Indicators */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-8">
        {[
          { label: 'Fleet Velocity', value: '42.8 km/h', sub: 'Optimal', icon: Zap, color: 'text-amber-400' },
          { label: 'On-Time Ratio', value: '98.2%', sub: '+1.4% WoW', icon: ShieldCheck, color: 'text-emerald-400' },
          { label: 'Active Shipments', value: orders.length, sub: 'LTM Data', icon: Truck, color: 'text-blue-400' },
          { label: 'Avg Transit', value: '1.2 Days', sub: '-4h vs Q3', icon: Clock, color: 'text-indigo-400' }
        ].map((kpi, i) => (
          <div key={i} className="bg-white p-8 rounded-[3rem] border border-slate-100 shadow-[0_20px_40px_-15px_rgba(0,0,0,0.05)] hover:shadow-2xl transition-all duration-500 group">
             <div className="flex justify-between items-start mb-4">
                <div className={`p-4 rounded-2xl bg-slate-50 ${kpi.color} transition-transform group-hover:scale-110`}>
                   <kpi.icon size={28} />
                </div>
                <ArrowUpRight size={20} className="text-slate-300" />
             </div>
             <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-1">{kpi.label}</p>
             <h4 className="text-3xl font-black text-slate-900 tracking-tighter">{kpi.value}</h4>
             <p className="text-xs font-bold text-slate-400 mt-1">{kpi.sub}</p>
          </div>
        ))}
      </div>

      {/* Main Order Ledger */}
      <div className="bg-white rounded-[4rem] border border-slate-200 shadow-2xl overflow-hidden">
        <div className="p-12 border-b border-slate-100 flex flex-col lg:flex-row justify-between items-start lg:items-center gap-8 bg-slate-50/30">
          <div>
            <h3 className="text-3xl font-black text-slate-900 tracking-tight">Real-Time Order Ledger</h3>
            <p className="text-lg text-slate-500 font-medium mt-1 italic">Sub-second synchronization with global fulfillment nodes</p>
          </div>
          <div className="relative w-full lg:w-96">
            <input 
              type="text" 
              placeholder="Search Global IDs..." 
              className="w-full pl-14 pr-6 py-5 bg-white border border-slate-200 rounded-[2rem] text-sm font-black text-slate-700 focus:ring-4 focus:ring-blue-600/5 focus:outline-none transition-all shadow-sm"
            />
            <div className="absolute left-5 top-5 text-slate-400">
              <Search size={24} />
            </div>
          </div>
        </div>

        <div className="divide-y divide-slate-100">
          {orders.map((order) => {
            const style = getStatusStyle(order.status);
            return (
              <div key={order.id} className="p-10 flex flex-wrap items-center justify-between gap-12 hover:bg-slate-50/80 transition-all duration-500 group relative">
                <div className="flex items-center gap-10 flex-1 min-w-[380px]">
                  <div className={`w-20 h-20 rounded-[2.5rem] border-2 flex items-center justify-center transition-all duration-700 group-hover:rotate-[360deg] ${style.bg} ${style.color} ${style.border} shadow-2xl`}>
                    {style.icon}
                  </div>
                  
                  <div className="space-y-3">
                    <div className="flex items-center gap-4">
                      <span className="font-mono text-xs font-black text-slate-400 tracking-tighter uppercase">{order.id}</span>
                      <span className={`px-4 py-1.5 rounded-full text-[9px] font-black uppercase tracking-[0.2em] border-2 shadow-sm ${style.color} ${style.bg} ${style.border}`}>
                        {order.status}
                      </span>
                    </div>
                    <h4 className="text-3xl font-black text-slate-900 tracking-tighter uppercase">{order.customerName}</h4>
                    <div className="flex items-center gap-5">
                      <p className="text-sm text-slate-500 font-bold flex items-center gap-2 italic">
                        <MapPin size={18} className="text-blue-600" />
                        {order.location}
                      </p>
                    </div>
                  </div>
                </div>
                
                <div className="flex items-center gap-20 shrink-0 w-full xl:w-auto justify-between xl:justify-end">
                  <div className="space-y-2">
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
                      <Clock size={14} className="text-blue-500" /> Telemetry Sync
                    </p>
                    <p className="text-lg font-black text-slate-800">{order.time}</p>
                  </div>
                  
                  <div className="space-y-2 text-right">
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Cargo Valuation</p>
                    <p className="text-2xl font-black text-slate-900 tracking-tight italic">${order.amount.toLocaleString()}</p>
                  </div>
                  
                  <button className="w-14 h-14 bg-slate-900 text-white rounded-2xl flex items-center justify-center hover:bg-blue-600 transition-all shadow-xl shadow-slate-900/20 active:scale-90 group-hover:scale-105">
                    <Navigation size={24} />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
        
        <div className="p-12 bg-slate-950 text-white flex flex-col md:flex-row justify-between items-center gap-8">
           <div className="flex items-center gap-6">
              <div className="w-16 h-16 rounded-full border-4 border-emerald-500/20 flex items-center justify-center text-emerald-400">
                 <ShieldCheck size={32} />
              </div>
              <div>
                 <h5 className="text-xl font-black tracking-tight">End-to-End Encryption</h5>
                 <p className="text-slate-500 text-sm font-bold mt-1 uppercase tracking-tighter">All GPS packets are AES-256 compliant</p>
              </div>
           </div>
           <button className="px-10 py-5 bg-white text-slate-950 rounded-[2rem] font-black text-xs uppercase tracking-widest hover:bg-slate-100 transition-all active:scale-95 shadow-2xl">
              Audit Logistics Stack
           </button>
        </div>
      </div>
    </div>
  );
};

export default OrderTracking;

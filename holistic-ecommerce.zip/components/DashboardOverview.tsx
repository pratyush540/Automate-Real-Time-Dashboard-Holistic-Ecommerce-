
import React from 'react';
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  BarChart,
  Bar,
  Cell
} from 'recharts';
import { DollarSign, TrendingUp, ShoppingBag, Percent } from 'lucide-react';

const data = [
  { name: 'Jan', revenue: 4000, gmv: 2400 },
  { name: 'Feb', revenue: 3000, gmv: 1398 },
  { name: 'Mar', revenue: 2000, gmv: 9800 },
  { name: 'Apr', revenue: 2780, gmv: 3908 },
  { name: 'May', revenue: 1890, gmv: 4800 },
  { name: 'Jun', revenue: 2390, gmv: 3800 },
  { name: 'Jul', revenue: 3490, gmv: 4300 },
];

const kpis = [
  { label: 'Total Revenue', value: '$84,200', change: 12.5, icon: DollarSign, color: 'bg-blue-500' },
  { label: 'Gross GMV', value: '$122,500', change: 8.2, icon: TrendingUp, color: 'bg-emerald-500' },
  { label: 'Total Orders', value: '1,240', change: 15.1, icon: ShoppingBag, color: 'bg-indigo-500' },
  { label: 'Avg Order Value', value: '$67.90', change: -2.4, icon: Percent, color: 'bg-amber-500' },
];

const DashboardOverview: React.FC = () => {
  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {kpis.map((kpi) => (
          <div key={kpi.label} className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm font-medium text-slate-500">{kpi.label}</p>
                <h3 className="text-2xl font-bold mt-1 text-slate-800">{kpi.value}</h3>
              </div>
              <div className={`${kpi.color} p-2.5 rounded-xl text-white`}>
                <kpi.icon size={20} />
              </div>
            </div>
            <div className="mt-4 flex items-center gap-2">
              <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${kpi.change >= 0 ? 'bg-emerald-50 text-emerald-600' : 'bg-red-50 text-red-600'}`}>
                {kpi.change >= 0 ? '+' : ''}{kpi.change}%
              </span>
              <span className="text-xs text-slate-400 font-medium">vs last month</span>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 bg-white p-8 rounded-2xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h3 className="text-lg font-bold text-slate-800">Revenue Performance</h3>
              <p className="text-sm text-slate-500">Monthly trend analysis</p>
            </div>
            <div className="flex gap-2">
              <button className="px-3 py-1.5 rounded-lg bg-blue-600 text-white text-xs font-bold">Revenue</button>
              <button className="px-3 py-1.5 rounded-lg bg-slate-100 text-slate-500 text-xs font-bold">GMV</button>
            </div>
          </div>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data}>
                <defs>
                  <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12}} />
                <YAxis axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12}} />
                <Tooltip 
                  contentStyle={{borderRadius: '12px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)'}}
                />
                <Area type="monotone" dataKey="revenue" stroke="#3b82f6" strokeWidth={3} fillOpacity={1} fill="url(#colorRevenue)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white p-8 rounded-2xl border border-slate-200 shadow-sm">
          <h3 className="text-lg font-bold text-slate-800 mb-6">Top Selling Categories</h3>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart layout="vertical" data={[
                { name: 'Electronics', value: 4500, color: '#3b82f6' },
                { name: 'Apparel', value: 3200, color: '#8b5cf6' },
                { name: 'Home', value: 2100, color: '#f59e0b' },
                { name: 'Wellness', value: 1500, color: '#10b981' },
              ]}>
                <XAxis type="number" hide />
                <YAxis dataKey="name" type="category" axisLine={false} tickLine={false} width={80} tick={{fill: '#64748b', fontSize: 12, fontWeight: 500}} />
                <Tooltip cursor={{fill: 'transparent'}} />
                <Bar dataKey="value" radius={[0, 4, 4, 0]} barSize={20}>
                  { [0, 1, 2, 3].map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={['#3b82f6', '#8b5cf6', '#f59e0b', '#10b981'][index]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DashboardOverview;

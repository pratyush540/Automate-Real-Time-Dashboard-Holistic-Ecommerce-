
import React, { useState, useMemo } from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from 'recharts';
import { MapPin, Search, UserPlus, Filter } from 'lucide-react';
import { MOCK_CUSTOMERS } from '../constants';

const CustomerSegmentation: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [pincodeFilter, setPincodeFilter] = useState('');

  const segmentData = [
    { name: 'VIP', value: 2, color: '#3b82f6' },
    { name: 'Regular', value: 2, color: '#10b981' },
    { name: 'New', value: 1, color: '#f59e0b' },
    { name: 'At Risk', value: 1, color: '#ef4444' },
  ];

  const sortedCustomers = useMemo(() => {
    return [...MOCK_CUSTOMERS].sort((a, b) => b.revenue - a.revenue);
  }, []);

  const uniquePincodes = useMemo(() => {
    return Array.from(new Set(MOCK_CUSTOMERS.map(c => c.pincode))).sort();
  }, []);

  const filteredCustomers = useMemo(() => {
    return MOCK_CUSTOMERS.filter(c => {
      const matchesSearch = c.name.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesPincode = pincodeFilter === '' || c.pincode === pincodeFilter;
      return matchesSearch && matchesPincode;
    });
  }, [searchTerm, pincodeFilter]);

  return (
    <div className="space-y-8 animate-in fade-in duration-700">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between mb-8">
             <h3 className="text-xl font-black text-slate-800 tracking-tight">Market Segmentation</h3>
             <button className="p-2 hover:bg-slate-100 rounded-xl text-slate-400 transition-colors"><Filter size={18} /></button>
          </div>
          <div className="h-[350px]">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={segmentData}
                  cx="50%"
                  cy="50%"
                  innerRadius={80}
                  outerRadius={120}
                  paddingAngle={8}
                  dataKey="value"
                >
                  {segmentData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} stroke="none" />
                  ))}
                </Pie>
                <Tooltip 
                   contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 25px rgba(0,0,0,0.1)' }}
                />
                <Legend iconType="circle" layout="vertical" align="right" verticalAlign="middle" wrapperStyle={{ paddingLeft: '20px' }} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between mb-8">
             <h3 className="text-xl font-black text-slate-800 tracking-tight">Revenue Leaders</h3>
             <button className="text-xs font-black text-blue-600 flex items-center gap-1">Detailed View <UserPlus size={14} /></button>
          </div>
          <div className="space-y-4">
            {sortedCustomers.slice(0, 5).map((customer) => (
              <div key={customer.id} className="flex items-center justify-between p-5 rounded-2xl bg-slate-50 border border-slate-100 hover:border-blue-400 hover:bg-white transition-all cursor-pointer group shadow-sm hover:shadow-md">
                <div className="flex items-center gap-5">
                  <div className={`w-14 h-14 rounded-2xl flex items-center justify-center font-black text-white shadow-lg transition-transform group-hover:scale-110
                    ${customer.segment === 'VIP' ? 'bg-blue-600 shadow-blue-600/20' : 'bg-slate-400'}`}>
                    {customer.name.substring(0, 2).toUpperCase()}
                  </div>
                  <div>
                    <h4 className="font-black text-slate-800 tracking-tight">{customer.name}</h4>
                    <p className="text-xs font-bold text-slate-400 flex items-center gap-1.5 mt-0.5">
                       <MapPin size={12} /> {customer.region} • {customer.orders} Trans.
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-lg font-black text-slate-900 tracking-tight">${customer.revenue.toLocaleString()}</p>
                  <span className={`text-[10px] font-black px-3 py-1 rounded-full uppercase tracking-widest mt-2 inline-block
                    ${customer.segment === 'VIP' ? 'bg-blue-100 text-blue-700' : 'bg-slate-200 text-slate-600'}`}>
                    {customer.segment}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="bg-white rounded-[2.5rem] border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-10 border-b border-slate-100 flex flex-col xl:flex-row justify-between items-start xl:items-center gap-6 bg-slate-50/30">
          <div>
            <h3 className="text-2xl font-black text-slate-800 tracking-tight">Universal Customer Directory</h3>
            <p className="text-sm text-slate-500 font-medium">Cross-filtering by region, segment, and ZIP protocols</p>
          </div>
          <div className="flex flex-wrap items-center gap-4 w-full xl:w-auto">
            <div className="relative flex-1 xl:flex-none xl:w-64">
              <input 
                type="text" 
                placeholder="Query by name..." 
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-12 pr-4 py-4 bg-white border border-slate-200 rounded-2xl text-sm font-bold text-slate-700 focus:ring-4 focus:ring-blue-500/10 focus:outline-none transition-all shadow-sm"
              />
              <div className="absolute left-4 top-4.5 text-slate-400"><Search size={20} /></div>
            </div>
            <div className="relative flex-1 xl:flex-none xl:w-48">
              <select
                value={pincodeFilter}
                onChange={(e) => setPincodeFilter(e.target.value)}
                className="w-full pl-12 pr-8 py-4 bg-white border border-slate-200 rounded-2xl text-sm font-bold text-slate-700 focus:ring-4 focus:ring-blue-500/10 focus:outline-none appearance-none cursor-pointer shadow-sm"
              >
                <option value="">Global Pincodes</option>
                {uniquePincodes.map(pin => (<option key={pin} value={pin}>{pin}</option>))}
              </select>
              <div className="absolute left-4 top-4.5 text-slate-400 pointer-events-none"><MapPin size={20} /></div>
            </div>
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-slate-50/50 text-slate-400 text-xs font-black uppercase tracking-widest border-b border-slate-100">
              <tr>
                <th className="px-10 py-6">Customer Profile</th>
                <th className="px-6 py-6">Intelligence Class</th>
                <th className="px-6 py-6">Geographical Node</th>
                <th className="px-6 py-6">ZIP Routing</th>
                <th className="px-6 py-6 text-right">Lifetime Ops</th>
                <th className="px-10 py-6 text-right">LTM Last Contact</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredCustomers.length > 0 ? filteredCustomers.map((c) => (
                <tr key={c.id} className="hover:bg-slate-50/50 transition-colors group">
                  <td className="px-10 py-6 font-black text-slate-800">{c.name}</td>
                  <td className="px-6 py-6">
                    <span className={`text-[10px] font-black px-4 py-1.5 rounded-full uppercase tracking-widest
                      ${c.segment === 'VIP' ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/20' : 
                        c.segment === 'At Risk' ? 'bg-rose-500 text-white shadow-lg shadow-rose-500/20' : 
                        c.segment === 'New' ? 'bg-amber-100 text-amber-700 border border-amber-200' : 'bg-slate-100 text-slate-700'}`}>
                      {c.segment}
                    </span>
                  </td>
                  <td className="px-6 py-6 text-sm font-bold text-slate-500">{c.region}</td>
                  <td className="px-6 py-6 text-sm text-slate-500 font-black tracking-tighter">{c.pincode}</td>
                  <td className="px-6 py-6 text-right font-black text-slate-900 tracking-tight">{c.orders}</td>
                  <td className="px-10 py-6 text-right text-xs font-bold text-slate-400">{c.lastOrder}</td>
                </tr>
              )) : (
                <tr>
                  <td colSpan={6} className="px-10 py-24 text-center text-slate-400 font-black">
                    Zero records match existing criteria profiles.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default CustomerSegmentation;

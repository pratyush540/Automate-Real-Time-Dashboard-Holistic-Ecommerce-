
import React, { useState, useEffect } from 'react';
import { Database, CheckCircle2, AlertCircle, RefreshCcw, ExternalLink, Activity, Wifi, ShieldCheck, Clock } from 'lucide-react';
import { CLOUD_SOURCES } from '../constants';
import { CloudSource } from '../types';

interface EnhancedCloudSource extends CloudSource {
  latency: number;
  uptime: string;
}

const CloudConnections: React.FC = () => {
  const [sources, setSources] = useState<EnhancedCloudSource[]>(
    CLOUD_SOURCES.map(s => ({ ...s, latency: s.connected ? Math.floor(Math.random() * 50) + 15 : 0, uptime: '99.9%' }))
  );
  const [syncingId, setSyncingId] = useState<string | null>(null);

  useEffect(() => {
    const interval = setInterval(() => {
      setSources(prev => prev.map(source => {
        if (!source.connected) return source;
        return {
          ...source,
          latency: Math.max(10, source.latency + (Math.random() * 10 - 5))
        };
      }));
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  const handleSync = (id: string) => {
    setSyncingId(id);
    setTimeout(() => {
      setSyncingId(null);
      setSources(prev => prev.map(s => s.id === id ? { ...s, lastSync: 'Just now', health: 'Healthy' as const } : s));
    }, 2000);
  };

  const getStatusConfig = (health: string, connected: boolean) => {
    if (!connected) return { color: 'text-slate-400', bg: 'bg-slate-100', label: 'Disconnected', icon: <AlertCircle size={14} /> };
    switch (health) {
      case 'Healthy': return { color: 'text-emerald-500', bg: 'bg-emerald-50', label: 'Healthy', icon: <CheckCircle2 size={14} />, pulse: true };
      case 'Degraded': return { color: 'text-amber-500', bg: 'bg-amber-50', label: 'Degraded', icon: <Activity size={14} /> };
      default: return { color: 'text-slate-400', bg: 'bg-slate-50', label: 'Offline', icon: <AlertCircle size={14} /> };
    }
  };

  return (
    <div className="max-w-5xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
      <div className="bg-gradient-to-br from-slate-900 via-blue-900 to-indigo-950 p-10 rounded-[2.5rem] text-white shadow-2xl shadow-blue-900/20 relative overflow-hidden">
        <div className="absolute top-0 right-0 p-12 opacity-10 pointer-events-none">
          <Database size={240} />
        </div>
        <div className="relative z-10">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-blue-500/20 rounded-full border border-blue-400/30 text-blue-200 text-xs font-bold uppercase tracking-widest mb-4">
            <Wifi size={14} className="animate-pulse" /> Live Infrastructure
          </div>
          <h3 className="text-4xl font-black mb-4 tracking-tight">Cloud Integration Hub</h3>
          <p className="text-blue-100/80 max-w-xl text-lg mb-8 leading-relaxed">
            Manage your enterprise data bridge with real-time health monitoring and automated synchronization protocols.
          </p>
          <div className="flex flex-wrap gap-4">
            <button className="px-8 py-3.5 bg-white text-slate-900 rounded-2xl font-bold text-sm hover:shadow-xl hover:-translate-y-0.5 transition-all">
              Provision New Endpoint
            </button>
            <button className="px-8 py-3.5 bg-slate-800/50 text-white rounded-2xl font-bold text-sm backdrop-blur-md border border-slate-700 hover:bg-slate-800/70 transition-all">
              View API Keys
            </button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6">
        {sources.map((source) => {
          const status = getStatusConfig(source.health, source.connected);
          const isSyncing = syncingId === source.id;

          return (
            <div key={source.id} className="bg-white p-8 rounded-[2rem] border border-slate-200 shadow-sm group hover:shadow-xl hover:border-blue-200 transition-all duration-500">
              <div className="flex flex-wrap items-center justify-between gap-8">
                <div className="flex items-center gap-8">
                  <div className={`p-5 rounded-3xl transition-all duration-500 ${source.connected ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/20 rotate-0' : 'bg-slate-100 text-slate-400 group-hover:rotate-6'}`}>
                    <Database size={36} />
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center gap-3">
                      <h4 className="text-2xl font-black text-slate-800 tracking-tight">{source.name}</h4>
                      <div className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest flex items-center gap-1.5 ${status.bg} ${status.color}`}>
                        {status.pulse && <span className="w-1.5 h-1.5 rounded-full bg-current animate-pulse"></span>}
                        {status.icon}
                        {status.label}
                      </div>
                    </div>
                    <div className="flex flex-wrap items-center gap-5">
                      <div className="flex items-center gap-1.5 text-xs text-slate-400 font-medium">
                        <Clock size={14} /> Last Sync: <span className="text-slate-600 font-bold">{source.lastSync}</span>
                      </div>
                      <div className="w-1 h-1 bg-slate-200 rounded-full"></div>
                      <div className="flex items-center gap-1.5 text-xs text-slate-400 font-medium">
                        <Activity size={14} /> Latency: <span className="text-emerald-600 font-bold">{source.connected ? `${source.latency.toFixed(0)}ms` : '—'}</span>
                      </div>
                      <div className="w-1 h-1 bg-slate-200 rounded-full"></div>
                      <div className="flex items-center gap-1.5 text-xs text-slate-400 font-medium">
                        <ShieldCheck size={14} /> SSL: <span className="text-slate-600 font-bold">Encrypted</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <button 
                    onClick={() => handleSync(source.id)}
                    disabled={!source.connected || isSyncing}
                    className={`p-3.5 rounded-2xl border border-slate-200 transition-all flex items-center gap-2 group/sync
                      ${isSyncing ? 'bg-slate-50 cursor-not-allowed' : 'hover:bg-blue-50 hover:border-blue-200'}
                      ${!source.connected && 'opacity-30 cursor-not-allowed'}`}
                    title="Force Manual Sync"
                  >
                    <RefreshCcw size={20} className={`text-slate-500 group-hover/sync:text-blue-600 ${isSyncing ? 'animate-spin text-blue-600' : ''}`} />
                    {isSyncing && <span className="text-xs font-bold text-blue-600">Syncing...</span>}
                  </button>

                  {source.connected ? (
                    <button className="px-6 py-3.5 bg-rose-50 text-rose-600 rounded-2xl font-bold text-sm hover:bg-rose-600 hover:text-white transition-all shadow-sm">
                      Terminate Session
                    </button>
                  ) : (
                    <button className="px-6 py-3.5 bg-blue-600 text-white rounded-2xl font-bold text-sm hover:bg-blue-700 transition-all flex items-center gap-2 shadow-lg shadow-blue-600/20 active:scale-95">
                      Establish Bridge <ExternalLink size={16} />
                    </button>
                  )}
                </div>
              </div>

              {source.connected && (
                <div className="mt-8 pt-6 border-t border-slate-100 grid grid-cols-2 md:grid-cols-4 gap-4">
                   <div className="bg-slate-50/50 p-4 rounded-2xl border border-slate-100">
                      <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Bandwidth</p>
                      <p className="text-sm font-bold text-slate-700">1.2 GB/s</p>
                   </div>
                   <div className="bg-slate-50/50 p-4 rounded-2xl border border-slate-100">
                      <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Queue Size</p>
                      <p className="text-sm font-bold text-slate-700">0 Tasks</p>
                   </div>
                   <div className="bg-slate-50/50 p-4 rounded-2xl border border-slate-100">
                      <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Success Rate</p>
                      <p className="text-sm font-bold text-emerald-600">99.98%</p>
                   </div>
                   <div className="bg-slate-50/50 p-4 rounded-2xl border border-slate-100">
                      <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">API Version</p>
                      <p className="text-sm font-bold text-slate-700">v4.2-stable</p>
                   </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default CloudConnections;


import React, { useState, useRef, useEffect } from 'react';
import { Search, Bell, Calendar, Filter, X, Package, User, ArrowRight, Check, Trash2, SlidersHorizontal, Map, Layers, DollarSign, ChevronDown } from 'lucide-react';
import { MOCK_PRODUCTS, MOCK_CUSTOMERS } from '../constants';

interface HeaderProps {
  activeTab: string;
}

const Header: React.FC<HeaderProps> = ({ activeTab }) => {
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [results, setResults] = useState<{ products: any[], customers: any[] }>({ products: [], customers: [] });
  const [showNotifications, setShowNotifications] = useState(false);
  const [showFilters, setShowFilters] = useState(false);
  
  const [selectedCategories, setSelectedCategories] = useState<string[]>(['Electronics']);
  const [revenueThreshold, setRevenueThreshold] = useState(50000);
  const [selectedYear, setSelectedYear] = useState('2024');

  const [notifications, setNotifications] = useState([
    { id: 1, title: 'Low Stock Alert', desc: 'Ultra-Wide Monitor is below reorder point.', type: 'alert', time: '2m ago', read: false },
    { id: 2, title: 'New VIP Customer', desc: 'Global Tech reached VIP status.', type: 'info', time: '15m ago', read: false },
    { id: 3, title: 'Order Delayed', desc: 'ORD-004 has a shipping location issue.', type: 'error', time: '1h ago', read: true },
  ]);

  const searchRef = useRef<HTMLDivElement>(null);
  const notificationRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (searchQuery.trim().length > 1) {
      const pMatch = MOCK_PRODUCTS.filter(p => p.name.toLowerCase().includes(searchQuery.toLowerCase())).slice(0, 3);
      const cMatch = MOCK_CUSTOMERS.filter(c => c.name.toLowerCase().includes(searchQuery.toLowerCase())).slice(0, 3);
      setResults({ products: pMatch, customers: cMatch });
    } else {
      setResults({ products: [], customers: [] });
    }
  }, [searchQuery]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setIsSearchOpen(false);
      }
      if (notificationRef.current && !notificationRef.current.contains(event.target as Node)) {
        setShowNotifications(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const unreadCount = notifications.filter(n => !n.read).length;

  const markAllRead = () => {
    setNotifications(notifications.map(n => ({ ...n, read: true })));
  };

  const toggleCategory = (cat: string) => {
    setSelectedCategories(prev => 
      prev.includes(cat) ? prev.filter(c => c !== cat) : [...prev, cat]
    );
  };

  return (
    <header className="h-20 bg-white border-b border-slate-200 px-8 flex items-center justify-between sticky top-0 z-40">
      <div className={`${isSearchOpen ? 'hidden md:block' : 'block'}`}>
        <h2 className="text-2xl font-bold text-slate-800">{activeTab}</h2>
        <p className="text-sm text-slate-500">Real-time performance analytics</p>
      </div>

      <div className="flex items-center gap-4 flex-1 justify-end">
        <div ref={searchRef} className="relative flex items-center justify-end flex-1 max-w-md">
          <div className={`flex items-center transition-all duration-300 overflow-hidden ${isSearchOpen ? 'w-full bg-slate-100 ring-2 ring-blue-500/20' : 'w-10 bg-transparent'} rounded-xl h-10`}>
            <button 
              onClick={() => setIsSearchOpen(!isSearchOpen)}
              className="p-2.5 text-slate-600 shrink-0 hover:bg-slate-200 transition-colors"
            >
              {isSearchOpen ? <Search size={18} /> : <Search size={20} />}
            </button>
            <input 
              type="text"
              placeholder="Search products, customers, orders..."
              className="bg-transparent border-none focus:outline-none text-sm w-full px-2 text-slate-700 font-medium"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              autoFocus={isSearchOpen}
            />
            {isSearchOpen && searchQuery && (
              <button onClick={() => setSearchQuery('')} className="p-2 text-slate-400 hover:text-slate-600">
                <X size={14} />
              </button>
            )}
          </div>

          {isSearchOpen && searchQuery.trim().length > 1 && (
            <div className="absolute top-12 right-0 w-full bg-white border border-slate-200 shadow-2xl rounded-2xl overflow-hidden animate-in fade-in slide-in-from-top-2 duration-200">
              <div className="p-4 space-y-4 max-h-[400px] overflow-y-auto custom-scrollbar">
                {results.products.length > 0 && (
                  <div>
                    <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 px-2">Products</h4>
                    <div className="space-y-1">
                      {results.products.map(p => (
                        <div key={p.id} className="flex items-center justify-between p-2 hover:bg-slate-50 rounded-lg cursor-pointer group">
                          <div className="flex items-center gap-3">
                            <div className="p-1.5 bg-blue-50 text-blue-600 rounded-md"><Package size={14} /></div>
                            <span className="text-sm font-semibold text-slate-700">{p.name}</span>
                          </div>
                          <ArrowRight size={14} className="text-slate-300 group-hover:text-blue-500 group-hover:translate-x-1 transition-all" />
                        </div>
                      ))}
                    </div>
                  </div>
                )}
                {results.customers.length > 0 && (
                  <div>
                    <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 px-2">Customers</h4>
                    <div className="space-y-1">
                      {results.customers.map(c => (
                        <div key={c.id} className="flex items-center justify-between p-2 hover:bg-slate-50 rounded-lg cursor-pointer group">
                          <div className="flex items-center gap-3">
                            <div className="p-1.5 bg-emerald-50 text-emerald-600 rounded-md"><User size={14} /></div>
                            <span className="text-sm font-semibold text-slate-700">{c.name}</span>
                          </div>
                          <ArrowRight size={14} className="text-slate-300 group-hover:text-blue-500 group-hover:translate-x-1 transition-all" />
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

        <div className="flex items-center gap-2">
          <div className="relative" ref={notificationRef}>
            <button 
              onClick={() => setShowNotifications(!showNotifications)}
              className={`p-2.5 rounded-xl transition-all relative ${showNotifications ? 'bg-blue-600 text-white shadow-lg' : 'bg-slate-100 hover:bg-slate-200 text-slate-600'}`}
            >
              <Bell size={20} />
              {unreadCount > 0 && (
                <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white text-[10px] font-bold flex items-center justify-center rounded-full border-2 border-white animate-bounce">
                  {unreadCount}
                </span>
              )}
            </button>

            {showNotifications && (
              <div className="absolute top-12 right-0 w-80 bg-white border border-slate-200 shadow-2xl rounded-2xl overflow-hidden animate-in fade-in slide-in-from-top-2 duration-200">
                <div className="p-4 bg-slate-50 border-b border-slate-100 flex items-center justify-between">
                  <h4 className="font-bold text-slate-800">Notifications</h4>
                  <button onClick={markAllRead} className="text-[10px] font-bold text-blue-600 hover:underline">Mark all read</button>
                </div>
                <div className="max-h-96 overflow-y-auto custom-scrollbar">
                  {notifications.map(n => (
                    <div key={n.id} className={`p-4 border-b border-slate-50 flex items-start gap-3 hover:bg-slate-50 transition-colors cursor-pointer ${!n.read ? 'bg-blue-50/30' : ''}`}>
                      <div className={`mt-1 w-2 h-2 rounded-full shrink-0 ${!n.read ? 'bg-blue-500' : 'bg-transparent'}`}></div>
                      <div className="flex-1">
                        <p className="text-sm font-bold text-slate-800">{n.title}</p>
                        <p className="text-xs text-slate-500 leading-snug mt-0.5">{n.desc}</p>
                        <span className="text-[10px] text-slate-400 font-medium mt-2 block">{n.time}</span>
                      </div>
                    </div>
                  ))}
                </div>
                <button className="w-full py-3 text-center text-xs font-bold text-slate-500 hover:bg-slate-50 border-t border-slate-100">View All Activity</button>
              </div>
            )}
          </div>

          <button 
            onClick={() => setShowFilters(true)}
            className="p-2.5 rounded-xl bg-blue-50 text-blue-600 hover:bg-blue-100 font-medium flex items-center gap-2 transition-all active:scale-95 group shadow-sm"
          >
            <Filter size={18} className="group-hover:rotate-12 transition-transform" />
            <span className="hidden sm:inline">Advanced Filters</span>
          </button>
        </div>
      </div>

      {showFilters && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-md transition-opacity duration-300" onClick={() => setShowFilters(false)}></div>
          <div className="relative w-full max-w-xl bg-white rounded-[3rem] shadow-2xl overflow-hidden animate-in zoom-in-95 slide-in-from-bottom-10 duration-300">
            <div className="p-10 border-b border-slate-100 flex items-center justify-between bg-gradient-to-r from-slate-50 to-white">
              <div className="flex items-center gap-4">
                <div className="p-3 bg-blue-600 text-white rounded-2xl shadow-xl shadow-blue-600/20"><SlidersHorizontal size={24} /></div>
                <div>
                  <h3 className="text-2xl font-black text-slate-800 tracking-tight">Intelligence Filters</h3>
                  <p className="text-sm text-slate-400 font-bold uppercase tracking-widest mt-1">Refine Dashboard context</p>
                </div>
              </div>
              <button 
                onClick={() => setShowFilters(false)} 
                className="p-3 hover:bg-slate-100 rounded-2xl text-slate-400 transition-colors"
              >
                <X size={24} />
              </button>
            </div>
            
            <div className="p-10 space-y-10 max-h-[70vh] overflow-y-auto custom-scrollbar">
              <div className="grid grid-cols-2 gap-8">
                <div className="space-y-3">
                  <label className="text-[11px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
                    <Calendar size={14} className="text-blue-500" /> Timeframe
                  </label>
                  <div className="relative group">
                    <select className="w-full bg-slate-50 border border-slate-200 p-4 rounded-2xl text-sm font-black text-slate-700 focus:ring-4 focus:ring-blue-500/10 focus:outline-none appearance-none transition-all cursor-pointer">
                      <option>Last 30 Days</option>
                      <option>Last 7 Days</option>
                      <option>Year to Date</option>
                      <option>Previous Quarter</option>
                      <option>Custom Range</option>
                    </select>
                    <ChevronDown size={16} className="absolute right-4 top-4 text-slate-400 pointer-events-none group-hover:translate-y-0.5 transition-transform" />
                  </div>
                </div>

                <div className="space-y-3">
                  <label className="text-[11px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
                    <Map size={14} className="text-indigo-500" /> Year
                  </label>
                  <div className="relative group">
                    <select 
                      value={selectedYear}
                      onChange={(e) => setSelectedYear(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 p-4 rounded-2xl text-sm font-black text-slate-700 focus:ring-4 focus:ring-blue-500/10 focus:outline-none appearance-none transition-all cursor-pointer"
                    >
                      <option>2024</option>
                      <option>2023</option>
                      <option>2022</option>
                    </select>
                    <ChevronDown size={16} className="absolute right-4 top-4 text-slate-400 pointer-events-none" />
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <label className="text-[11px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
                  <Layers size={14} className="text-emerald-500" /> Product Categories
                </label>
                <div className="flex flex-wrap gap-3">
                  {['Electronics', 'Apparel', 'Home', 'Wellness'].map(cat => (
                    <button 
                      key={cat} 
                      onClick={() => toggleCategory(cat)}
                      className={`px-6 py-3 rounded-2xl text-xs font-black transition-all border-2 flex items-center gap-3
                        ${selectedCategories.includes(cat) 
                          ? 'bg-blue-600 border-blue-600 text-white shadow-lg shadow-blue-600/20' 
                          : 'bg-white border-slate-100 text-slate-400 hover:border-blue-200 hover:text-blue-600 shadow-sm'}`}
                    >
                      {selectedCategories.includes(cat) && <Check size={14} />}
                      {cat}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-6">
                <div className="flex justify-between items-center">
                  <label className="text-[11px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
                    <DollarSign size={14} className="text-amber-500" /> Revenue Threshold
                  </label>
                  <span className="text-sm font-black text-blue-600 bg-blue-50 px-4 py-1.5 rounded-full border border-blue-100 shadow-sm">
                    ${revenueThreshold.toLocaleString()}+
                  </span>
                </div>
                <div className="relative pt-2">
                  <input 
                    type="range" 
                    min="0" 
                    max="200000" 
                    step="5000"
                    value={revenueThreshold}
                    onChange={(e) => setRevenueThreshold(parseInt(e.target.value))}
                    className="w-full h-3 bg-slate-100 rounded-full appearance-none cursor-pointer accent-blue-600 hover:accent-blue-700 transition-all shadow-inner" 
                  />
                  <div className="flex justify-between text-[10px] font-black text-slate-400 mt-4 px-1">
                    <span className="bg-slate-50 px-2 py-1 rounded-md">MIN $0</span>
                    <span className="bg-slate-50 px-2 py-1 rounded-md">MAX $200k+</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="p-10 bg-slate-50 border-t border-slate-100 flex items-center gap-5">
              <button 
                onClick={() => setShowFilters(false)} 
                className="flex-1 py-5 bg-slate-900 text-white rounded-[2rem] font-black text-sm hover:bg-slate-800 transition-all shadow-2xl shadow-slate-900/30 active:scale-95 flex items-center justify-center gap-3"
              >
                Apply Intelligence <ArrowRight size={18} />
              </button>
              <button 
                onClick={() => {
                  setSelectedCategories([]);
                  setRevenueThreshold(0);
                }}
                className="px-8 py-5 bg-white text-slate-400 rounded-[2rem] font-bold text-sm border-2 border-slate-100 hover:text-rose-500 hover:border-rose-200 transition-all group"
                title="Reset Filters"
              >
                <Trash2 size={24} className="group-hover:shake" />
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;


import React, { useState, useEffect } from 'react';
import { ShoppingCart, MapPin, User, Clock, CreditCard, ArrowRight, Zap, CheckCircle2 } from 'lucide-react';
import { MOCK_ORDERS } from '../constants';
import { Order } from '../types';

const SalesHub: React.FC = () => {
  const [liveOrders, setLiveOrders] = useState<Order[]>(MOCK_ORDERS);
  const [isStreaming, setIsStreaming] = useState(true);

  useEffect(() => {
    if (!isStreaming) return;

    const interval = setInterval(() => {
      const newOrder: Order = {
        id: `ORD-${Math.floor(Math.random() * 900) + 100}`,
        customerName: ['Sarah Jenkins', 'Acme Corp', 'Pioneer Sol.', 'John Doe', 'Tech Galaxy'][Math.floor(Math.random() * 5)],
        status: 'Placed',
        location: `${Math.floor(Math.random() * 999) + 1} Main St, ${['San Francisco', 'Chicago', 'Miami', 'Seattle'][Math.floor(Math.random() * 4)]}, USA`,
        time: 'Just Now',
        amount: Math.floor(Math.random() * 5000) + 100,
      };

      setLiveOrders(prev => [newOrder, ...prev.slice(0, 9)]);
    }, 8000);

    return () => clearInterval(interval);
  }, [isStreaming]);

  return (
    <div className="space-y-8 animate-in fade-in duration-700">
      <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm flex flex-col md:flex-row items-center justify-between gap-6">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <span className="flex h-2 w-2 rounded-full bg-emerald-500 animate-pulse"></span>
            <span className="text-xs font-bold text-emerald-600 uppercase tracking-widest">Live Order Stream</span>
          </div>
          <h2 className="text-3xl font-black text-slate-900 tracking-tight">Real-Time Sales Hub</h2>
          <p className="text-slate-500 mt-1">Monitoring all incoming traffic and transactional data in real-time.</p>
        </div>
        <div className="flex items-center gap-4 bg-slate-50 p-2 rounded-2xl border border-slate-100">
          <span className="text-sm font-bold text-slate-600 px-3">Auto-update</span>
          <button 
            onClick={() => setIsStreaming(!isStreaming)}
            className={`relative inline-flex h-8 w-14 items-center rounded-full transition-colors focus:outline-none ${isStreaming ? 'bg-blue-600' : 'bg-slate-300'}`}
          >
            <span className={`inline-block h-6 w-6 transform rounded-full bg-white transition-transform ${isStreaming ? 'translate-x-7' : 'translate-x-1'}`} />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-4">
          <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2">
            <Zap size={20} className="text-amber-500" />
            Recent Transactions
          </h3>
          <div className="space-y-4">
            {liveOrders.map((order, idx) => (
              <div 
                key={`${order.id}-${idx}`} 
                className={`bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-col md:flex-row justify-between gap-6 group hover:border-blue-400 transition-all hover:shadow-lg ${idx === 0 && isStreaming ? 'animate-in slide-in-from-top-4 duration-500 border-emerald-400 bg-emerald-50/10' : ''}`}
              >
                <div className="flex items-start gap-5">
                  <div className={`p-4 rounded-2xl ${idx === 0 && isStreaming ? 'bg-emerald-500 text-white shadow-emerald-500/20' : 'bg-slate-100 text-slate-400 group-hover:bg-blue-500 group-hover:text-white group-hover:shadow-lg group-hover:shadow-blue-500/20'} transition-all`}>
                    <ShoppingCart size={24} />
                  </div>
                  <div className="space-y-1">
                    <div className="flex items-center gap-3">
                      <span className="font-mono text-xs font-bold text-slate-400">{order.id}</span>
                      {idx === 0 && isStreaming && (
                        <span className="bg-emerald-100 text-emerald-700 text-[10px] font-black px-2 py-0.5 rounded-full uppercase tracking-tighter animate-bounce">New Order</span>
                      )}
                    </div>
                    <h4 className="text-xl font-black text-slate-800 tracking-tight flex items-center gap-2">
                      <User size={18} className="text-slate-400" />
                      {order.customerName}
                    </h4>
                    <p className="text-sm text-slate-500 flex items-center gap-1.5">
                      <MapPin size={14} className="text-slate-400" />
                      {order.location}
                    </p>
                  </div>
                </div>

                <div className="flex flex-row md:flex-col items-center md:items-end justify-between md:justify-center gap-2 border-t md:border-t-0 pt-4 md:pt-0 border-slate-100">
                  <div className="text-right">
                    <div className="flex items-center gap-1 text-slate-400 text-xs font-bold uppercase mb-1">
                      <CreditCard size={12} /> Amount
                    </div>
                    <p className="text-2xl font-black text-slate-900 tracking-tight">${order.amount.toLocaleString()}</p>
                  </div>
                  <div className="flex items-center gap-2 bg-slate-50 px-3 py-1 rounded-full border border-slate-200">
                    <Clock size={12} className="text-slate-400" />
                    <span className="text-xs font-bold text-slate-600">{order.time}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="space-y-8">
          <div className="bg-slate-900 p-8 rounded-[2.5rem] text-white shadow-2xl relative overflow-hidden h-fit">
            <div className="absolute -top-10 -right-10 w-40 h-40 bg-blue-600/20 rounded-full blur-3xl"></div>
            <div className="relative z-10">
              <h3 className="text-xl font-bold mb-6">Order Statistics</h3>
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <span className="text-slate-400 font-medium">Processing</span>
                  <span className="font-bold">24 Orders</span>
                </div>
                <div className="w-full bg-slate-800 h-2 rounded-full">
                  <div className="bg-blue-500 h-full w-[65%] rounded-full shadow-[0_0_10px_rgba(59,130,246,0.5)]"></div>
                </div>
                
                <div className="flex items-center justify-between">
                  <span className="text-slate-400 font-medium">In Transit</span>
                  <span className="font-bold">18 Orders</span>
                </div>
                <div className="w-full bg-slate-800 h-2 rounded-full">
                  <div className="bg-emerald-500 h-full w-[40%] rounded-full shadow-[0_0_10px_rgba(16,185,129,0.5)]"></div>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-slate-400 font-medium">Flagged Issues</span>
                  <span className="font-bold text-rose-400">2 Orders</span>
                </div>
                <div className="w-full bg-slate-800 h-2 rounded-full">
                  <div className="bg-rose-500 h-full w-[10%] rounded-full"></div>
                </div>
              </div>
              
              <button className="w-full mt-10 py-4 bg-white text-slate-900 rounded-2xl font-black text-sm flex items-center justify-center gap-2 hover:bg-slate-100 transition-all active:scale-95">
                Download Order Log <ArrowRight size={18} />
              </button>
            </div>
          </div>

          <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm border-l-8 border-emerald-500">
            <div className="flex items-center gap-3 mb-4 text-emerald-600">
              <CheckCircle2 size={24} />
              <h4 className="font-black">Direct Sync Enabled</h4>
            </div>
            <p className="text-sm text-slate-500 leading-relaxed">
              New customer orders are automatically synced from your storefront to this dashboard with sub-second latency.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SalesHub;


import React from 'react';
import { AlertCircle, PackageCheck, AlertTriangle, Layers, PieChart as PieChartIcon, BellRing, PackageSearch } from 'lucide-react';
import { MOCK_PRODUCTS, INVENTORY_CATEGORIES } from '../constants';

const SupplyControl: React.FC = () => {
  const lowStockItems = MOCK_PRODUCTS.filter(p => p.stock > 0 && p.stock <= p.reorderPoint);
  const outOfStockItems = MOCK_PRODUCTS.filter(p => p.stock === 0);
  const totalValue = INVENTORY_CATEGORIES.reduce((acc, cat) => acc + cat.value, 0);

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
          <div className="flex items-center gap-4">
            <div className="bg-blue-500 p-3 rounded-xl text-white">
              <PackageCheck size={24} />
            </div>
            <div>
              <p className="text-xs font-medium text-slate-500">Total Stock Value</p>
              <h3 className="text-xl font-bold text-slate-800">${totalValue.toLocaleString()}</h3>
            </div>
          </div>
        </div>
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
          <div className="flex items-center gap-4">
            <div className="bg-emerald-500 p-3 rounded-xl text-white">
              <Layers size={24} />
            </div>
            <div>
              <p className="text-xs font-medium text-slate-500">Active SKUs</p>
              <h3 className="text-xl font-bold text-slate-800">{MOCK_PRODUCTS.length}</h3>
            </div>
          </div>
        </div>
        <div className={`bg-white p-6 rounded-2xl border border-slate-200 shadow-sm transition-all ${lowStockItems.length > 0 ? 'ring-2 ring-amber-500/20 bg-amber-50/10' : ''}`}>
          <div className="flex items-center gap-4">
            <div className={`${lowStockItems.length > 0 ? 'bg-amber-500 animate-pulse' : 'bg-slate-400'} p-3 rounded-xl text-white`}>
              <AlertTriangle size={24} />
            </div>
            <div>
              <p className="text-xs font-medium text-slate-500">Low Stock SKUs</p>
              <h3 className="text-xl font-bold text-slate-800">{lowStockItems.length}</h3>
            </div>
          </div>
        </div>
        <div className={`bg-white p-6 rounded-2xl border border-slate-200 shadow-sm transition-all ${outOfStockItems.length > 0 ? 'ring-2 ring-red-500/20 bg-red-50/10' : ''}`}>
          <div className="flex items-center gap-4">
            <div className={`${outOfStockItems.length > 0 ? 'bg-red-600 animate-bounce' : 'bg-slate-400'} p-3 rounded-xl text-white`}>
              <AlertCircle size={24} />
            </div>
            <div>
              <p className="text-xs font-medium text-slate-500">Stockouts</p>
              <h3 className="text-xl font-bold text-slate-800">{outOfStockItems.length}</h3>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-1 space-y-6">
          <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm">
            <div className="flex items-center gap-3 mb-6">
              <div className="p-2 bg-indigo-50 text-indigo-600 rounded-lg">
                <PieChartIcon size={20} />
              </div>
              <h3 className="text-lg font-bold text-slate-800">Inventory Value Breakdown</h3>
            </div>
            <div className="space-y-6">
              {INVENTORY_CATEGORIES.map((cat) => (
                <div key={cat.category}>
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-sm font-semibold text-slate-600">{cat.category}</span>
                    <span className="text-sm font-bold text-slate-800">${cat.value.toLocaleString()}</span>
                  </div>
                  <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-blue-600 rounded-full shadow-[0_0_8px_rgba(37,99,235,0.4)]" 
                      style={{ width: `${(cat.value / totalValue) * 100}%` }}
                    ></div>
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-8 pt-6 border-t border-slate-100">
              <div className="flex items-center justify-between text-sm">
                <span className="text-slate-500 font-medium">Global Average Value</span>
                <span className="text-slate-800 font-bold">${(totalValue / INVENTORY_CATEGORIES.length).toLocaleString()}</span>
              </div>
            </div>
          </div>

          <div className="bg-slate-900 p-8 rounded-3xl text-white overflow-hidden relative group">
            <div className="absolute -right-8 -bottom-8 opacity-10 group-hover:scale-125 transition-transform duration-500">
              <PackageSearch size={160} />
            </div>
            <h4 className="text-xl font-black mb-4">Stock Optimization</h4>
            <p className="text-sm text-slate-400 mb-6 leading-relaxed">AI recommends clearing 12% of Home Goods category to improve turnover rate.</p>
            <button className="w-full py-4 bg-white text-slate-900 rounded-2xl font-black text-xs hover:bg-slate-100 transition-all flex items-center justify-center gap-2">
              Optimize Inventory <BellRing size={16} />
            </button>
          </div>
        </div>

        <div className="lg:col-span-2 bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
          <div className="p-8 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
            <div>
              <h3 className="text-lg font-bold text-slate-800">Critical Reorder Queue</h3>
              <p className="text-sm text-slate-500">Real-time alerts for supply continuity</p>
            </div>
            <button className="px-6 py-3 bg-blue-600 text-white rounded-2xl text-xs font-black shadow-xl shadow-blue-600/20 hover:bg-blue-700 transition-all active:scale-95">
              Bulk Reorder SKUs
            </button>
          </div>
          <div className="divide-y divide-slate-100">
            {outOfStockItems.length === 0 && lowStockItems.length === 0 && (
              <div className="p-20 text-center space-y-4">
                <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto">
                  <PackageCheck size={32} />
                </div>
                <p className="text-slate-400 font-bold">All inventory levels are optimal.</p>
              </div>
            )}
            {outOfStockItems.map(p => (
              <div key={p.id} className="p-6 flex items-center justify-between border-l-8 border-red-600 bg-red-50/10 animate-pulse">
                <div className="flex items-center gap-5">
                  <div className="w-12 h-12 rounded-2xl bg-red-600 flex items-center justify-center text-white shadow-lg shadow-red-600/20">
                    <AlertCircle size={24} />
                  </div>
                  <div>
                    <h4 className="font-black text-slate-800 tracking-tight">{p.name}</h4>
                    <p className="text-[10px] text-red-600 font-black uppercase tracking-widest mt-1 bg-red-100 px-2 py-0.5 rounded-full inline-block">Urgent: Out of Stock</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-xs font-bold text-slate-400 uppercase tracking-tighter mb-1">Stock: {p.stock}</p>
                  <button className="text-xs font-black text-blue-600 hover:text-blue-700 flex items-center gap-1 justify-end">
                    Manual Sync <PackageCheck size={14} />
                  </button>
                </div>
              </div>
            ))}
            {lowStockItems.map(p => (
              <div key={p.id} className="p-6 flex items-center justify-between border-l-8 border-amber-500 hover:bg-slate-50 transition-colors">
                <div className="flex items-center gap-5">
                  <div className="w-12 h-12 rounded-2xl bg-amber-100 flex items-center justify-center text-amber-600 border border-amber-200">
                    <AlertTriangle size={24} />
                  </div>
                  <div>
                    <h4 className="font-black text-slate-800 tracking-tight">{p.name}</h4>
                    <p className="text-[10px] text-amber-600 font-black uppercase tracking-widest mt-1">Warning: {p.stock} Units Remaining</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-xs font-bold text-slate-400 uppercase tracking-tighter mb-1">Target: {p.reorderPoint}</p>
                  <button className="px-4 py-2 bg-blue-50 text-blue-600 rounded-xl font-black text-[10px] hover:bg-blue-600 hover:text-white transition-all">
                    Automate Reorder
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default SupplyControl;

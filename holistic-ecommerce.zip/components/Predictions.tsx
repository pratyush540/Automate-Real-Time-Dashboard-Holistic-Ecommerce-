
import React, { useState, useEffect } from 'react';
import { 
  Sparkles, 
  TrendingUp, 
  Info, 
  Target, 
  Users, 
  ArrowUpRight, 
  BrainCircuit,
  Zap,
  Flame,
  Search
} from 'lucide-react';
import { 
  Radar, 
  RadarChart, 
  PolarGrid, 
  PolarAngleAxis, 
  PolarRadiusAxis, 
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Cell
} from 'recharts';
import { getSalesPrediction } from '../services/gemini';
import { MOCK_PRODUCTS } from '../constants';

const Predictions: React.FC = () => {
  const [predictions, setPredictions] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedProduct, setSelectedProduct] = useState<string>('');

  useEffect(() => {
    const fetchPredictions = async () => {
      setLoading(true);
      const productStr = MOCK_PRODUCTS.map(p => `${p.name}: ${p.revenue} rev, ${p.velocity} vel`).join(', ');
      const result = await getSalesPrediction(productStr);
      setPredictions(result);
      if (result.length > 0) setSelectedProduct(result[0].productName);
      setLoading(false);
    };
    fetchPredictions();
  }, []);

  const radarData = [
    { subject: 'Velocity', A: 80, B: 95, fullMark: 100 },
    { subject: 'Margin', A: 65, B: 70, fullMark: 100 },
    { subject: 'Retention', A: 45, B: 60, fullMark: 100 },
    { subject: 'Conv. Rate', A: 30, B: 85, fullMark: 100 },
    { subject: 'Search Vol', A: 50, B: 90, fullMark: 100 },
  ];

  const customerSearchData = [
    { name: '4K Monitors', interest: 88, color: '#3b82f6' },
    { name: 'Wireless Audio', interest: 94, color: '#8b5cf6' },
    { name: 'Home Office', interest: 72, color: '#10b981' },
    { name: 'Sustainable Wear', interest: 65, color: '#f59e0b' },
    { name: 'Smart Kitchen', interest: 58, color: '#ef4444' },
  ];

  return (
    <div className="space-y-8 animate-in fade-in duration-700">
      <div className="bg-gradient-to-br from-indigo-900 via-slate-900 to-slate-950 rounded-[2.5rem] p-10 text-white relative overflow-hidden shadow-2xl shadow-indigo-500/10">
        <div className="absolute top-0 right-0 p-12 opacity-10">
          <BrainCircuit size={300} />
        </div>
        <div className="relative z-10 max-w-2xl">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-indigo-500/20 rounded-full border border-indigo-400/30 text-indigo-300 text-xs font-black uppercase tracking-widest mb-6">
            <Sparkles size={14} className="animate-pulse" /> Neural Forecast Engine
          </div>
          <h2 className="text-5xl font-black mb-6 tracking-tighter">AI Growth & Consumer Strategy</h2>
          <p className="text-indigo-100/70 text-lg leading-relaxed">
            Predictive modeling identifies high-yield opportunities before they peak. We analyze sub-currents in customer behavior to recommend your next strategic move.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-8">
          <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="flex items-center justify-between mb-8">
              <div>
                <h3 className="text-xl font-black text-slate-800 tracking-tight">Focus Recommendation: {selectedProduct || 'Analyzing...'}</h3>
                <p className="text-sm text-slate-500">Current performance vs. Predicted potential</p>
              </div>
              <div className="flex gap-2">
                <span className="px-3 py-1 bg-emerald-50 text-emerald-600 text-[10px] font-black uppercase rounded-lg border border-emerald-100 flex items-center gap-1">
                  <TrendingUp size={12} /> High Yield
                </span>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <RadarChart cx="50%" cy="50%" outerRadius="80%" data={radarData}>
                    <PolarGrid stroke="#e2e8f0" />
                    <PolarAngleAxis dataKey="subject" tick={{ fill: '#64748b', fontSize: 11, fontWeight: 700 }} />
                    <Radar
                      name="Current"
                      dataKey="A"
                      stroke="#94a3b8"
                      fill="#94a3b8"
                      fillOpacity={0.2}
                    />
                    <Radar
                      name="Predicted"
                      dataKey="B"
                      stroke="#3b82f6"
                      fill="#3b82f6"
                      fillOpacity={0.5}
                    />
                    <Tooltip />
                  </RadarChart>
                </ResponsiveContainer>
              </div>
              <div className="space-y-6">
                <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100">
                  <h4 className="font-bold text-slate-800 flex items-center gap-2 mb-2">
                    <Target size={18} className="text-blue-600" />
                    Strategic Focus
                  </h4>
                  <p className="text-sm text-slate-600 leading-relaxed">
                    This product shows a **95% velocity increase** in the next cycle. Recommend increasing marketing budget by **15%** specifically targeting returning VIP customers.
                  </p>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="p-4 bg-blue-50/50 rounded-2xl border border-blue-100">
                    <p className="text-[10px] font-black text-blue-500 uppercase mb-1">Stock Risk</p>
                    <p className="text-lg font-black text-blue-900">High</p>
                  </div>
                  <div className="p-4 bg-emerald-50/50 rounded-2xl border border-emerald-100">
                    <p className="text-[10px] font-black text-emerald-500 uppercase mb-1">ROI Est.</p>
                    <p className="text-lg font-black text-emerald-900">3.4x</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {loading ? (
              [1, 2, 3].map(i => <div key={i} className="h-48 bg-white rounded-3xl animate-pulse border border-slate-200" />)
            ) : (
              predictions.slice(0, 3).map((pred, i) => (
                <button 
                  key={i} 
                  onClick={() => setSelectedProduct(pred.productName)}
                  className={`bg-white p-6 rounded-3xl border transition-all text-left group hover:shadow-xl ${selectedProduct === pred.productName ? 'border-blue-500 ring-2 ring-blue-500/10' : 'border-slate-200'}`}
                >
                  <div className="flex items-center justify-between mb-4">
                    <div className="p-2 bg-slate-100 rounded-xl group-hover:bg-blue-600 group-hover:text-white transition-colors">
                      <Zap size={20} />
                    </div>
                    <span className="text-[10px] font-black text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-md">+{pred.predictedGrowth}</span>
                  </div>
                  <h4 className="font-black text-slate-800 mb-2 truncate">{pred.productName}</h4>
                  <p className="text-xs text-slate-400 line-clamp-2 leading-relaxed">{pred.reason}</p>
                </button>
              ))
            )}
          </div>
        </div>

        <div className="space-y-8">
          <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm">
            <div className="flex items-center gap-3 mb-8">
              <div className="p-2 bg-amber-50 text-amber-600 rounded-lg">
                <Users size={20} />
              </div>
              <div>
                <h3 className="text-lg font-black text-slate-800 tracking-tight">Customer Demand POV</h3>
                <p className="text-xs text-slate-400 font-medium">Trending search & interest scores</p>
              </div>
            </div>
            
            <div className="h-[250px] mb-8">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={customerSearchData} layout="vertical" margin={{ left: -20 }}>
                  <XAxis type="number" hide />
                  <YAxis dataKey="name" type="category" axisLine={false} tickLine={false} width={100} tick={{ fill: '#64748b', fontSize: 10, fontWeight: 700 }} />
                  <Tooltip cursor={{ fill: '#f8fafc' }} />
                  <Bar dataKey="interest" radius={[0, 4, 4, 0]} barSize={12}>
                    {customerSearchData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} fillOpacity={0.8} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>

            <div className="space-y-4">
              <div className="flex items-center gap-4 p-4 bg-slate-50 rounded-2xl border border-slate-100 group">
                <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 font-black">1</div>
                <div>
                  <h5 className="text-sm font-bold text-slate-800">Upsell Tech Bundles</h5>
                  <p className="text-xs text-slate-400">Customers are searching for "Kits"</p>
                </div>
              </div>
              <div className="flex items-center gap-4 p-4 bg-slate-50 rounded-2xl border border-slate-100 group">
                <div className="w-10 h-10 rounded-full bg-purple-100 flex items-center justify-center text-purple-600 font-black">2</div>
                <div>
                  <h5 className="text-sm font-bold text-slate-800">Launch Pre-Orders</h5>
                  <p className="text-xs text-slate-400">High search vol for next-gen audio</p>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-slate-900 p-8 rounded-3xl text-white relative overflow-hidden group shadow-2xl shadow-slate-900/20">
            <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:scale-125 transition-transform">
              <Flame size={120} />
            </div>
            <div className="relative z-10">
              <h4 className="text-xl font-black mb-4 flex items-center gap-2">
                <ArrowUpRight className="text-emerald-400" />
                Action Required
              </h4>
              <p className="text-sm text-slate-400 mb-8 leading-relaxed">
                We've detected a shift in "At Risk" customer behavior. They are showing interest in your New Arrivals.
              </p>
              <button className="w-full py-4 bg-emerald-500 text-white rounded-2xl font-black text-sm flex items-center justify-center gap-2 hover:bg-emerald-600 transition-all active:scale-95 shadow-lg shadow-emerald-500/20">
                Execute Loyalty Campaign
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Predictions;

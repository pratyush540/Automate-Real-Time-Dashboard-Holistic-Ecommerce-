
import React from 'react';
import { 
  LayoutDashboard, 
  Package, 
  Users, 
  ClipboardList, 
  MapPin, 
  Cloud, 
  TrendingUp,
  Menu,
  ChevronLeft,
  PieChart,
  Zap,
  UploadCloud,
  FileText,
  Truck
} from 'lucide-react';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  isOpen: boolean;
  toggleSidebar: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ activeTab, setActiveTab, isOpen, toggleSidebar }) => {
  const menuItems = [
    { name: 'Overview', icon: LayoutDashboard },
    { name: 'Executive', icon: PieChart },
    { name: 'Sales Hub', icon: Zap },
    { name: 'Logistics', icon: Truck },
    { name: 'Products', icon: Package },
    { name: 'Customers', icon: Users },
    { name: 'Inventory', icon: ClipboardList },
    { name: 'Predictions', icon: TrendingUp },
    { name: 'Data Center', icon: UploadCloud },
    { name: 'Cloud', icon: Cloud },
    { name: 'Reports', icon: FileText },
  ];

  return (
    <div className={`${isOpen ? 'w-64' : 'w-20'} bg-slate-900 text-white transition-all duration-300 flex flex-col h-full border-r border-slate-800 shrink-0`}>
      <div className="p-6 flex items-center justify-between">
        {isOpen && <h1 className="text-xl font-bold bg-gradient-to-r from-blue-400 to-indigo-500 bg-clip-text text-transparent">Holistic</h1>}
        <button onClick={toggleSidebar} className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700">
          {isOpen ? <ChevronLeft size={20} /> : <Menu size={20} />}
        </button>
      </div>

      <nav className="flex-1 px-3 space-y-2 mt-4 overflow-y-auto custom-scrollbar">
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.name;
          return (
            <button
              key={item.name}
              onClick={() => setActiveTab(item.name)}
              className={`w-full flex items-center p-3 rounded-xl transition-all ${
                isActive ? 'bg-blue-600 text-white shadow-lg shadow-blue-900/40' : 'text-slate-400 hover:bg-slate-800 hover:text-white'
              }`}
            >
              <Icon size={22} className={isActive ? 'mr-3' : 'mx-auto'} />
              {isOpen && <span className="font-medium whitespace-nowrap">{item.name}</span>}
            </button>
          );
        })}
      </nav>

      <div className="p-4 border-t border-slate-800">
        <div className={`flex items-center gap-3 ${!isOpen && 'justify-center'}`}>
          <div className="w-10 h-10 rounded-full bg-indigo-500 flex items-center justify-center font-bold">HE</div>
          {isOpen && (
            <div className="overflow-hidden">
              <p className="text-sm font-semibold truncate">Ecommerce Admin</p>
              <p className="text-xs text-slate-500 truncate">holistic@corp.com</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Sidebar;

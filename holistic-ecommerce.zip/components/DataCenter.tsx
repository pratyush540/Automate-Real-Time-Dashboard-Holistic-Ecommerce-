
import React, { useState } from 'react';
import { UploadCloud, FileText, Database, ShieldCheck, CheckCircle2, AlertCircle, FileJson, Table } from 'lucide-react';

const DataCenter: React.FC = () => {
  const [isDragging, setIsDragging] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);

  const simulateUpload = () => {
    setIsUploading(true);
    let progress = 0;
    const interval = setInterval(() => {
      progress += 10;
      setUploadProgress(progress);
      if (progress >= 100) {
        clearInterval(interval);
        setTimeout(() => {
          setIsUploading(false);
          setUploadProgress(0);
          alert('Data ingestion complete! Processing records...');
        }, 500);
      }
    }, 200);
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
      <div className="bg-white p-10 rounded-[2.5rem] border border-slate-200 shadow-sm">
        <div className="max-w-3xl mx-auto text-center space-y-4 mb-12">
          <h2 className="text-4xl font-black text-slate-900 tracking-tight">Data Ingestion Center</h2>
          <p className="text-slate-500 text-lg">
            Import bulk sales data, customer lists, or product inventory records directly into your analytical workspace.
          </p>
        </div>

        <div 
          onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
          onDragLeave={() => setIsDragging(false)}
          onDrop={(e) => { e.preventDefault(); setIsDragging(false); simulateUpload(); }}
          className={`max-w-4xl mx-auto border-4 border-dashed rounded-[3rem] p-20 flex flex-col items-center justify-center transition-all duration-300 ${isDragging ? 'border-blue-500 bg-blue-50/50 scale-[1.02]' : 'border-slate-200 bg-slate-50/30'}`}
        >
          {isUploading ? (
            <div className="w-full max-w-md space-y-6 text-center">
              <div className="relative h-2 w-full bg-slate-200 rounded-full overflow-hidden">
                <div 
                  className="absolute top-0 left-0 h-full bg-blue-600 transition-all duration-300 shadow-[0_0_15px_rgba(37,99,235,0.4)]"
                  style={{ width: `${uploadProgress}%` }}
                />
              </div>
              <p className="text-sm font-black text-blue-600 uppercase tracking-widest animate-pulse">Syncing Data Streams... {uploadProgress}%</p>
            </div>
          ) : (
            <>
              <div className="w-24 h-24 bg-blue-600 text-white rounded-[2rem] flex items-center justify-center shadow-2xl shadow-blue-600/30 mb-8">
                <UploadCloud size={48} />
              </div>
              <h3 className="text-2xl font-bold text-slate-800 mb-2">Drag & drop your files here</h3>
              <p className="text-slate-400 font-medium mb-8">Supported formats: CSV, JSON, XLSX (Max 100MB)</p>
              <button 
                onClick={simulateUpload}
                className="px-10 py-4 bg-slate-900 text-white rounded-2xl font-black text-sm hover:bg-slate-800 transition-all active:scale-95 shadow-xl shadow-slate-900/20"
              >
                Browse My Computer
              </button>
            </>
          )}
        </div>

        <div className="max-w-4xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-6 mt-16">
          <div className="bg-slate-50 p-6 rounded-3xl border border-slate-100 flex items-start gap-4">
            <div className="p-3 bg-white rounded-2xl text-slate-400 shadow-sm">
              <ShieldCheck size={24} />
            </div>
            <div>
              <h4 className="font-bold text-slate-800">Secure Transfer</h4>
              <p className="text-xs text-slate-500 mt-1">AES-256 end-to-end encryption for all file uploads.</p>
            </div>
          </div>
          <div className="bg-slate-50 p-6 rounded-3xl border border-slate-100 flex items-start gap-4">
            <div className="p-3 bg-white rounded-2xl text-slate-400 shadow-sm">
              <CheckCircle2 size={24} />
            </div>
            <div>
              <h4 className="font-bold text-slate-800">Auto Validation</h4>
              <p className="text-xs text-slate-500 mt-1">Automatic schema matching and data cleaning.</p>
            </div>
          </div>
          <div className="bg-slate-50 p-6 rounded-3xl border border-slate-100 flex items-start gap-4">
            <div className="p-3 bg-white rounded-2xl text-slate-400 shadow-sm">
              <Database size={24} />
            </div>
            <div>
              <h4 className="font-bold text-slate-800">Snowflake Bridge</h4>
              <p className="text-xs text-slate-500 mt-1">Direct ingest into your analytical warehouse.</p>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-8 border-b border-slate-100 flex justify-between items-center">
          <h3 className="text-xl font-black text-slate-800 tracking-tight">Recent Import Logs</h3>
          <div className="flex gap-2">
            <span className="bg-slate-100 text-slate-500 text-[10px] font-bold px-2.5 py-1 rounded-full uppercase">All Jobs</span>
          </div>
        </div>
        <div className="divide-y divide-slate-100">
          {[
            { name: 'q4_sales_raw.csv', type: 'CSV', size: '24.5MB', status: 'Success', date: '2 hours ago', icon: Table, color: 'text-blue-500 bg-blue-50' },
            { name: 'customer_segments.json', type: 'JSON', size: '1.2MB', status: 'Success', date: '5 hours ago', icon: FileJson, color: 'text-amber-500 bg-amber-50' },
            { name: 'inventory_master.xlsx', type: 'XLSX', size: '12.8MB', status: 'Failed', date: '1 day ago', icon: FileText, color: 'text-rose-500 bg-rose-50' },
          ].map((job, idx) => (
            <div key={idx} className="p-6 flex items-center justify-between hover:bg-slate-50/50 transition-colors">
              <div className="flex items-center gap-5">
                <div className={`p-3 rounded-2xl ${job.color}`}>
                  <job.icon size={20} />
                </div>
                <div>
                  <h5 className="font-bold text-slate-800">{job.name}</h5>
                  <div className="flex items-center gap-3 text-xs text-slate-400 mt-0.5">
                    <span className="font-bold">{job.size}</span>
                    <span className="w-1 h-1 bg-slate-200 rounded-full"></span>
                    <span>{job.date}</span>
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-8">
                <div className="text-right hidden sm:block">
                  <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Type</p>
                  <p className="text-sm font-bold text-slate-600">{job.type}</p>
                </div>
                <div className={`px-4 py-1.5 rounded-full text-[10px] font-black uppercase flex items-center gap-1.5 ${job.status === 'Success' ? 'bg-emerald-100 text-emerald-700' : 'bg-rose-100 text-rose-700'}`}>
                  {job.status === 'Success' ? <CheckCircle2 size={12} /> : <AlertCircle size={12} />}
                  {job.status}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default DataCenter;

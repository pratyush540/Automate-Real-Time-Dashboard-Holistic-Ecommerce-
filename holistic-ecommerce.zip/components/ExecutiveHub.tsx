
import React, { useState } from 'react';
import { TrendingUp, TrendingDown, DollarSign, Calendar, Mic, ArrowUpRight, ArrowDownRight } from 'lucide-react';

const DAILY_STATS = [
  { date: '2023-11-23', revenue: 4200, profit: 1200, loss: 150, topProduct: 'Ultra-Wide Monitor' },
  { date: '2023-11-22', revenue: 3800, profit: 950, loss: 200, topProduct: 'Ergonomic Keyboard' },
  { date: '2023-11-21', revenue: 5100, profit: 1600, loss: 300, topProduct: 'Noise Canceling Headphones' },
  { date: '2023-11-20', revenue: 2900, profit: 600, loss: 100, topProduct: 'Cotton Blend T-Shirt' },
  { date: '2023-11-19', revenue: 4500, profit: 1300, loss: 50, topProduct: 'Smart Coffee Maker' },
];

const ExecutiveHub: React.FC = () => {
  const [selectedDate, setSelectedDate] = useState('2023-11-23');

  const totalProfit = 152400;
  const totalLoss = 34200;
  const netRevenue = 118200;

  return (
    <div className="space-y-8">
      <div className="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm flex flex-col md:flex-row items-center justify-between gap-6 bg-gradient-to-br from-white to-slate-50">
        <div>
          <h2 className="text-3xl font-extrabold text-slate-900 tracking-tight">Executive Summary</h2>
          <p className="text-slate-500 mt-2 text-lg">Quick glance at your business health and profitability.</p>
        </div>
        <button className="flex items-center gap-3 bg-blue-600 hover:bg-blue-700 text-white px-8 py-4 rounded-2xl font-bold text-lg shadow-xl shadow-blue-500/20 transition-all active:scale-95">
          <Mic size={24} />
          Ask with Voice
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="bg-emerald-500 p-8 rounded-3xl text-white shadow-xl shadow-emerald-500/20 relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:scale-110 transition-transform">
            <TrendingUp size={120} />
          </div>
          <div className="relative z-10">
            <div className="flex items-center gap-2 mb-2 text-emerald-100 font-bold uppercase tracking-wider text-sm">
              <TrendingUp size={16} /> Total Gross Profit
            </div>
            <h3 className="text-5xl font-black">${totalProfit.toLocaleString()}</h3>
            <div className="mt-6 flex items-center gap-2 text-emerald-100 font-semibold">
              <ArrowUpRight size={20} /> +14% from last month
            </div>
          </div>
        </div>

        <div className="bg-rose-500 p-8 rounded-3xl text-white shadow-xl shadow-rose-500/20 relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:scale-110 transition-transform">
            <TrendingDown size={120} />
          </div>
          <div className="relative z-10">
            <div className="flex items-center gap-2 mb-2 text-rose-100 font-bold uppercase tracking-wider text-sm">
              <TrendingDown size={16} /> Total Expenses & Loss
            </div>
            <h3 className="text-5xl font-black">${totalLoss.toLocaleString()}</h3>
            <div className="mt-6 flex items-center gap-2 text-rose-100 font-semibold">
              <ArrowDownRight size={20} /> -2% from last month
            </div>
          </div>
        </div>

        <div className="bg-slate-900 p-8 rounded-3xl text-white shadow-xl shadow-slate-900/20 relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:scale-110 transition-transform">
            <DollarSign size={120} />
          </div>
          <div className="relative z-10">
            <div className="flex items-center gap-2 mb-2 text-slate-400 font-bold uppercase tracking-wider text-sm">
               Net Performance
            </div>
            <h3 className="text-5xl font-black">${netRevenue.toLocaleString()}</h3>
            <div className="mt-6 flex items-center gap-2 text-blue-400 font-semibold">
              Strong growth period
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-8 border-b border-slate-100 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <h3 className="text-xl font-bold text-slate-800">Performance By Date</h3>
            <p className="text-sm text-slate-500">Track daily revenue and top-performing products.</p>
          </div>
          <div className="flex items-center gap-3 bg-slate-50 p-2 rounded-2xl border border-slate-200">
            <Calendar size={18} className="text-slate-400 ml-2" />
            <input 
              type="date" 
              className="bg-transparent text-sm font-bold focus:outline-none text-slate-700 p-2"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
            />
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-slate-50/50 text-slate-500 text-xs font-bold uppercase tracking-widest">
              <tr>
                <th className="px-8 py-6">Date</th>
                <th className="px-6 py-6 text-right">Revenue</th>
                <th className="px-6 py-6 text-right">Profit</th>
                <th className="px-6 py-6 text-right">Loss</th>
                <th className="px-8 py-6">Best Performing Product</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {DAILY_STATS.map((stat) => (
                <tr key={stat.date} className={`hover:bg-slate-50 transition-colors ${stat.date === selectedDate ? 'bg-blue-50/30' : ''}`}>
                  <td className="px-8 py-6 font-bold text-slate-700">{stat.date}</td>
                  <td className="px-6 py-6 text-right font-mono text-slate-800 font-bold">${stat.revenue.toLocaleString()}</td>
                  <td className="px-6 py-6 text-right text-emerald-600 font-bold">+${stat.profit.toLocaleString()}</td>
                  <td className="px-6 py-6 text-right text-rose-500 font-bold">-${stat.loss.toLocaleString()}</td>
                  <td className="px-8 py-6">
                    <span className="inline-flex items-center gap-2 px-4 py-1.5 bg-blue-50 text-blue-700 rounded-full font-bold text-sm">
                      <TrendingUp size={14} /> {stat.topProduct}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default ExecutiveHub;

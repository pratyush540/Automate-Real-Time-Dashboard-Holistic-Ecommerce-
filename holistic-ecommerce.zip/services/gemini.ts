
import { GoogleGenAI, Type } from "@google/genai";

const getAi = () => new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const askDashboardAssistant = async (query: string, dataSummary: string) => {
  const ai = getAi();
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Context: You are a sales analyst assistant for Holistic Ecommerce. 
      Dashboard Data Summary: ${dataSummary}
      User Query: ${query}
      Respond concisely for a non-IT stakeholder. Focus on KPIs like profit, revenue, and performance.`,
    });
    return response.text;
  } catch (error) {
    console.error("AI Assistant Error:", error);
    return "I couldn't process that query right now. Please try again.";
  }
};

export const getSalesPrediction = async (productData: string) => {
  const ai = getAi();
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Analyze this product data and predict which products will sell more based on current performance and trends. 
      Data: ${productData}
      Provide the response in JSON format.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              productName: { type: Type.STRING },
              predictedGrowth: { type: Type.STRING },
              reason: { type: Type.STRING }
            },
            required: ["productName", "predictedGrowth", "reason"]
          }
        }
      }
    });
    return JSON.parse(response.text);
  } catch (error) {
    console.error("Prediction Error:", error);
    return [];
  }
};

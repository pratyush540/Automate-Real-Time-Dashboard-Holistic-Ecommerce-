
export interface KPIData {
  label: string;
  value: string;
  change: number;
  prefix?: string;
}

export interface ProductPerformance {
  id: string;
  name: string;
  category: string;
  revenue: number;
  quantitySold: number;
  velocity: number;
  conversionRate: number;
  clicks: number;
  stock: number;
  reorderPoint: number;
}

export interface Customer {
  id: string;
  name: string;
  revenue: number;
  orders: number;
  segment: 'VIP' | 'Regular' | 'At Risk' | 'New';
  region: string;
  lastOrder: string;
  pincode: string;
}

export interface Order {
  id: string;
  customerName: string;
  status: 'Placed' | 'Shipped' | 'Delivered' | 'Issue';
  location: string;
  time: string;
  amount: number;
}

export interface CloudSource {
  id: string;
  name: 'Snowflake' | 'AWS Redshift' | 'Google BigQuery';
  connected: boolean;
  lastSync: string;
  health: 'Healthy' | 'Degraded' | 'Offline';
}

export interface InventoryCategory {
  category: string;
  value: number;
}


import React, { useState } from 'react';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import DashboardOverview from './components/DashboardOverview';
import ProductInsights from './components/ProductInsights';
import CustomerSegmentation from './components/CustomerSegmentation';
import SupplyControl from './components/SupplyControl';
import CloudConnections from './components/CloudConnections';
import Predictions from './components/Predictions';
import AiAssistant from './components/AiAssistant';
import ExecutiveHub from './components/ExecutiveHub';
import SalesHub from './components/SalesHub';
import DataCenter from './components/DataCenter';
import ReportGenerator from './components/ReportGenerator';
import OrderTracking from './components/OrderTracking';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState('Overview');
  const [isSidebarOpen, setSidebarOpen] = useState(true);

  const renderContent = () => {
    switch (activeTab) {
      case 'Overview': return <DashboardOverview />;
      case 'Executive': return <ExecutiveHub />;
      case 'Sales Hub': return <SalesHub />;
      case 'Logistics': return <OrderTracking />;
      case 'Products': return <ProductInsights />;
      case 'Customers': return <CustomerSegmentation />;
      case 'Inventory': return <SupplyControl />;
      case 'Data Center': return <DataCenter />;
      case 'Cloud': return <CloudConnections />;
      case 'Predictions': return <Predictions />;
      case 'Reports': return <ReportGenerator />;
      default: return <DashboardOverview />;
    }
  };

  return (
    <div className="flex h-screen overflow-hidden text-slate-900">
      <Sidebar 
        activeTab={activeTab} 
        setActiveTab={setActiveTab} 
        isOpen={isSidebarOpen}
        toggleSidebar={() => setSidebarOpen(!isSidebarOpen)}
      />
      
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden relative">
        <Header activeTab={activeTab} />
        
        <main className="flex-1 overflow-y-auto p-4 md:p-8 custom-scrollbar">
          <div className="max-w-7xl mx-auto space-y-8 animate-in fade-in duration-500">
            {renderContent()}
          </div>
        </main>

        <AiAssistant />
      </div>
    </div>
  );
};

export default App;

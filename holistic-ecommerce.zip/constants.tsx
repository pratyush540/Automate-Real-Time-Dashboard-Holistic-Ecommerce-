
import { ProductPerformance, Customer, Order, CloudSource, InventoryCategory } from './types';

export const MOCK_PRODUCTS: ProductPerformance[] = [
  { id: '1', name: 'Ultra-Wide Monitor', category: 'Electronics', revenue: 45000, quantitySold: 120, velocity: 8.5, conversionRate: 0.12, clicks: 1200, stock: 45, reorderPoint: 50 },
  { id: '2', name: 'Ergonomic Keyboard', category: 'Electronics', revenue: 12000, quantitySold: 300, velocity: 15.2, conversionRate: 0.25, clicks: 2400, stock: 12, reorderPoint: 40 },
  { id: '3', name: 'Active Noise Canceling Headphones', category: 'Electronics', revenue: 32000, quantitySold: 160, velocity: 10.1, conversionRate: 0.15, clicks: 1800, stock: 0, reorderPoint: 20 },
  { id: '4', name: 'Smart Watch Series X', category: 'Electronics', revenue: 28000, quantitySold: 140, velocity: 7.8, conversionRate: 0.10, clicks: 3500, stock: 85, reorderPoint: 30 },
  { id: '5', name: 'Designer Leather Jacket', category: 'Apparel', revenue: 15000, quantitySold: 50, velocity: 3.2, conversionRate: 0.05, clicks: 9000, stock: 5, reorderPoint: 15 },
  { id: '6', name: 'Cotton Blend T-Shirt', category: 'Apparel', revenue: 8000, quantitySold: 400, velocity: 25.0, conversionRate: 0.35, clicks: 6000, stock: 120, reorderPoint: 100 },
  { id: '7', name: 'Running Sneakers Pro', category: 'Apparel', revenue: 22000, quantitySold: 110, velocity: 9.2, conversionRate: 0.18, clicks: 4500, stock: 30, reorderPoint: 25 },
  { id: '8', name: 'Smart Coffee Maker', category: 'Home', revenue: 19000, quantitySold: 95, velocity: 6.5, conversionRate: 0.09, clicks: 2100, stock: 8, reorderPoint: 15 },
  { id: '9', name: 'Organic Bedding Set', category: 'Home', revenue: 14000, quantitySold: 70, velocity: 4.1, conversionRate: 0.07, clicks: 1200, stock: 18, reorderPoint: 10 },
  { id: '10', name: 'Portable Power Station', category: 'Electronics', revenue: 55000, quantitySold: 55, velocity: 2.1, conversionRate: 0.04, clicks: 5000, stock: 3, reorderPoint: 10 }
];

export const MOCK_CUSTOMERS: Customer[] = [
  { id: 'C1', name: 'Acme Corp', revenue: 125000, orders: 45, segment: 'VIP', region: 'North', lastOrder: '2023-11-20', pincode: '10001' },
  { id: 'C2', name: 'Global Tech', revenue: 98000, orders: 32, segment: 'VIP', region: 'East', lastOrder: '2023-11-18', pincode: '20005' },
  { id: 'C3', name: 'Sarah Jenkins', revenue: 1500, orders: 3, segment: 'New', region: 'South', lastOrder: '2023-11-22', pincode: '30301' },
  { id: 'C4', name: 'Mega Retailers', revenue: 75000, orders: 25, segment: 'Regular', region: 'West', lastOrder: '2023-11-15', pincode: '90210' },
  { id: 'C5', name: 'Pioneer Sol.', revenue: 54000, orders: 18, segment: 'Regular', region: 'North', lastOrder: '2023-11-10', pincode: '10002' },
  { id: 'C6', name: 'Old Store', revenue: 8000, orders: 12, segment: 'At Risk', region: 'East', lastOrder: '2023-08-05', pincode: '20101' },
];

export const MOCK_ORDERS: Order[] = [
  { id: 'ORD-001', customerName: 'Acme Corp', status: 'Delivered', location: 'New York, NY', time: '10:30 AM', amount: 4500 },
  { id: 'ORD-002', customerName: 'Global Tech', status: 'Shipped', location: 'Boston, MA', time: '11:15 AM', amount: 2800 },
  { id: 'ORD-003', customerName: 'Sarah Jenkins', status: 'Placed', location: 'Atlanta, GA', time: '12:45 PM', amount: 450 },
  { id: 'ORD-004', customerName: 'Mega Retailers', status: 'Issue', location: 'Home Address - Not Found', time: '01:20 PM', amount: 1200 },
  { id: 'ORD-005', customerName: 'Pioneer Sol.', status: 'Shipped', location: 'Jersey City, NJ', time: '02:00 PM', amount: 3100 },
];

export const CLOUD_SOURCES: CloudSource[] = [
  { id: 'S1', name: 'Snowflake', connected: true, lastSync: '2 min ago', health: 'Healthy' },
  { id: 'S2', name: 'AWS Redshift', connected: false, lastSync: 'N/A', health: 'Offline' },
  { id: 'S3', name: 'Google BigQuery', connected: false, lastSync: 'N/A', health: 'Offline' }
];

export const INVENTORY_CATEGORIES: InventoryCategory[] = [
  { category: 'Electronics', value: 245000 },
  { category: 'Apparel', value: 85000 },
  { category: 'Home', value: 62000 },
  { category: 'Accessories', value: 18000 }
];
